#!/usr/bin/env python3
#
# INTEL CONFIDENTIAL
#
# Copyright 2021 (c) Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials, and
# your use of them  is governed by the  express license under which  they were
# provided to you ("License"). Unless the License provides otherwise, you  may
# not  use,  modify,  copy, publish,  distribute,  disclose  or transmit  this
# software or the related documents without Intel"s prior written permission.
#
# This software and the related documents are provided as is, with no  express
# or implied  warranties, other  than those  that are  expressly stated in the
# License.
#
# ----------------------------------------------------------------------------
import csv
from star_fw.framework_base.logger.api_intf_logger import LoggerAPI

logging = LoggerAPI(device_tag='wlc_bench')
import os
import shutil

import pexpect

'''
Set of utility functions for capturing tool data from various profiling tools
These functions were ported from the work done in src-kpi-runners repo

Authors:
Dinu Munteanu <marian.dinu-munteanu@intel.com>
Cosmin Albescu <cosmin.albescu@intel.com>

Contributors:
Bijalwan, AnkeshX <ankeshx.bijalwan@intel.com>

'''


def get_gpu_top_data(gpu_log_file="./logs/log_stdout_intel_gpu_top.log"):
    """
    Function to obtain GPU frequency and render usage from the intel_gpu_top log file
    :param gpu_log_file: log file where intel_gpu_top is stored,
    default value is ./logs/og_stdout_intel_gpu_top
    :return: array[int, float]: gpu usage, first element is gpu frequency, second element is gpu render
    """
    gpu_value = []

    # check if file exists
    if os.path.exists(gpu_log_file) and os.path.isfile(gpu_log_file):
        logging.debug("GPU intel_gpu_top file {gpu_log_file} exists, reading values")
    else:
        logging.error("GPU intel_gpu_top file {gpu_log_file} not found")
        return ["Nan", "Nan"]

    # Read last 3 lines of intel_gpu_top log in order to obtain GPU usage
    with open(gpu_log_file, "r") as f:
        line = f.read().splitlines()
        # Obtain the render percentage value from the intel gpu log
        # Render position might vary from device to device
        first_line = line[0].split()
        if ":" in line[0]:
            first_line = line[0].split(":")[-1].split()
        second_line = line[0].split()
        # The percentage usage value of render is first displayed
        render_position = first_line.index("RCS/0")
        percentage_position = render_position
        # Sanity check of percentage for render usage position
        if second_line[render_position] != "%":
            logging.info("Might not be able to obtain correct position, trying to parse second line")
            for index, element in enumerate(second_line):
                if str(element) == "%" and str(second_line[index + 1]) == "se" and str(second_line[index + 2]) == "wa":
                    if index >= render_position:
                        # found correct render percentage index position, store it and stop for loop
                        percentage_position = index
                        break

        for gpu_line in line[-3:]:
            if gpu_line.split()[0].isdigit():
                gpu_freq = gpu_line.split()[1]
                gpu_render = gpu_line.split()[percentage_position]
                gpu_value = [gpu_freq, float(gpu_render) / 100]

    return gpu_value


def get_cpu_top_data(cpu_log_file="./logs/log_stdout_top.log"):
    """
    Function to obtain CPU usage and Memory usage (RAM and SWAP) from the top log file
    :param cpu_log_file: log file where top is stored, default value is ./logs/log_stdout_top
    :return: dict["CPU Usage"], cpu overall usage (user + system) in absolute value as float
    :return: dict["RAM Usage"], memory used from RAM only in MiB
    :return: dict["Total RAM"], total amount of RAM memory only in MiB
    :return: dict["SWAP Usage"], memory used from SWAP only in MiB
    :return: dict["Total SWAP"], total ammount of SWAP configured in MiB
    """
    # Initialize return value as empty
    top_return_dict = {}
    # In case values are not found, set them to -1 to observ error in logs
    cpu_value = -1
    ram_usage = -1
    total_ram = -1
    swap_usage = -1
    total_swap = -1

    # check if file exists
    if os.path.exists(cpu_log_file) and os.path.isfile(cpu_log_file):
        logging.debug(f"CPU top file {cpu_log_file} exists, reading values")

    else:
        logging.error(f"CPU top file {cpu_log_file} not found")
        return "Nan"

    # read last 8 lines of the top log to obtain the CPU usage,
    # if top returns other process then self, then last lines read will be increased
    with open(cpu_log_file, "r") as cpu_log:
        cpu_lines = cpu_log.read().splitlines()[-8:]

        for line in cpu_lines:
            # Obtain CPU Usage
            if line.startswith("%Cpu(s)"):
                # add sy, us, ni times from top
                cpu_line = line.split(":")[1].strip()
                cpu_value = float(cpu_line.split()[0]) + float(cpu_line.split()[2]) + float(cpu_line.split()[4])

            # Obtain RAM values
            if line.startswith("MiB Mem"):
                # RAM memory usage is 5th element from line after column mark
                ram_usage = line.split(":")[1].strip().split()[4]
                # Total RAM is 1st element from line after column mark
                total_ram = line.split(":")[1].strip().split()[0]
            # Obtain Swap values
            if line.startswith("MiB Swap"):
                # Swap usage is 5th element from line after column mark
                swap_usage = line.split(":")[1].strip().split()[4]
                # Total Swap alocation is 1st element from line after column mark
                total_swap = line.split(":")[1].strip().split()[0]

    top_return_dict["CPU Usage"] = float(cpu_value) / 100
    top_return_dict["RAM Usage"] = f"{ram_usage} Mb"
    top_return_dict["Total RAM"] = f"{total_ram} Mb"
    top_return_dict["Swap Usage"] = f"{swap_usage} Mb"
    top_return_dict["Total Swap"] = f"{total_swap} Mb"
    return top_return_dict


# TODO: not tested, no PDU connected, needs to be tested
def get_pdu_target_power(tool):
    """
    Function to obtain current power consumption of DUT from PDU
    :param tool tool obj created when wlc_bench gets launched holding all attributes of that tool
    :return: float: current power consumption value from PDU measured in Amps
    """

    # Display the current power consumption
    pdu = pexpect.spawn("ssh " + tool["username"] + "@" + tool["ip"])
    logging.debug("Connection to PDU established")

    pdu.expect("password: ")
    pdu.sendline(tool["password"])
    pdu.expect("> ")
    logging.debug("Password accepted")

    pdu.sendline(tool["start_cmd"])
    logging.debug("Sent power outlet get command")

    pdu.expect("> ")
    target_power = str(pdu.before).split("Reading:")[1].split()[0]
    logging.debug("Received output from PDU")

    return target_power


def get_cpu_socwatch_power(num_wl_started, socwatch_log_file="./SoCWatchOutput.csv"):
    """
    Function to obtain CPU average power and CPU total power from the Socwatch log file
    :param num_wl_started: total # of wl started till this point
    :param socwatch_log_file: log file where output is stored, default - ./logs/log_stdout_socwatch
    :return: array[int, int]: CPU power usage,
             first element is CPU average power (mW), second element is CPU total power (mJ)
    """
    # check if file exists
    if os.path.exists(socwatch_log_file) and os.path.isfile(socwatch_log_file):
        logging.debug(f"CPU socwatch file {socwatch_log_file} exists, reading values")

    else:
        logging.info(f"CPU socwatch file {socwatch_log_file} not found")
        return ["Nan", "Nan", "Nan"]

    # Read the output csv from socwatch log in order to obtain CPU power
    metric_type_power = "Power"
    metric_type_memory = "Total"
    cpu_power = ["Nan", "Nan", "Nan"]
    with open(socwatch_log_file, "r") as csv_file:
        csv_data = csv.reader(csv_file, delimiter=",")

        for line in csv_data:
            row = [element.strip() for element in line]

            if metric_type_power in row:
                cpu_avg_power = row[2]
                cpu_total_power = row[3]
                cpu_power[0] = cpu_avg_power
                cpu_power[1]= cpu_total_power
            if metric_type_memory in row:
                total_memory_bw = row[2]
                cpu_power[2] = total_memory_bw

    # move all logs to ./logs directory always, keep source dir clean
    shutil.move(socwatch_log_file, f"./logs/{socwatch_log_file}_{num_wl_started}_wl_started.log")
    shutil.move("./SoCWatchOutput.sw2", "./logs/SocWatchOutput.sw2")

    return cpu_power
