#!/bin/bash

# Check that time series directory exists
if [[ ! -d ../../time-series-proxy-workload/wlc-bench/ ]]
then
    echo "[ERROR] Time series directory does not exist"
    exit 1
fi

# Check that NVR directory exists
if [[ ! -d ../../frameworks.benchmarking.edge-systems.nvr-bench/nvr_bench_runner/ ]]
then
    echo "[ERROR] NVR directory does not exist"
    exit 1
fi

# Execute Time Series
cp time_series.yaml ../../time-series-proxy-workload/wlc-bench/
cd ../../time-series-proxy-workload/wlc-bench/
python3 /home/$USER/frameworks.benchmarking.edge-systems.wlc-bench/wlc_bench.py time_series.yaml
sleep 1

# Execute NVR
cd /home/$USER/frameworks.benchmarking.edge-systems.wlc-bench/regression_tests/
cp nvr.yaml ../../frameworks.benchmarking.edge-systems.nvr-bench/nvr_bench_runner/
cp config_high.json ../../frameworks.benchmarking.edge-systems.nvr-bench/nvr_bench_runner/config/
cd ../../frameworks.benchmarking.edge-systems.nvr-bench/nvr_bench_runner/
python3 /home/$USER/frameworks.benchmarking.edge-systems.wlc-bench/wlc_bench.py nvr.yaml

# Verify synbench logs
if [[ $(grep fps ../../time-series-proxy-workload/wlc-bench/logs/log_stdout_synbench-proxy-high_wl_1.log | wc -l) -gt 0 ]]
then
    echo "[SUCCESS] Synbench test passed"
else
    echo "[ERROR] Synbench test failed"
    exit 1
fi

# Verify time series logs
if [[ $(grep Connected ../../time-series-proxy-workload/wlc-bench/logs/log_stdout_time_series-measured_add_ts-svm_med_wl_2.log | wc -l) -gt 0 ]]
then
    echo "[SUCCESS] Time series test passed"
else
    echo "[ERROR] Time series test failed"
    exit 1
fi

# Verify NVR logs
if [[ $(grep FpsCounter ../../frameworks.benchmarking.edge-systems.nvr-bench/nvr_bench_runner/logs/log_stdout_nvrbench-measured_indu_high-high_wl_1.log | wc -l) -gt 0 ]]
then
    echo "[SUCCESS] NVR test passed"
else
    echo "[ERROR] NVR test failed"
    exit 1
fi