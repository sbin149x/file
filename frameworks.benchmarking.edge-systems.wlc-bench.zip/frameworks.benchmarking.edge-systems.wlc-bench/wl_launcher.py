#!/usr/bin/env python3
#
# INTEL CONFIDENTIAL
#
# Copyright 2021 (c) Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials, and
# your use of them  is governed by the  express license under which  they were
# provided to you ("License"). Unless the License provides otherwise, you  may
# not  use,  modify,  copy, publish,  distribute,  disclose  or transmit  this
# software or the related documents without Intel"s prior written permission.
#
# This software and the related documents are provided as is, with no  express
# or implied  warranties, other  than those  that are  expressly stated in the
# License.
#
# ----------------------------------------------------------------------------

import glob
import json
import re
import os
import statistics
import subprocess
import time

import psutil
from datetime import datetime
import pandas as pd
import tempfile

from broker import *
from star_fw.framework_base.star_decorator import StarDecorator

disconnect = False
wl_count = 0
metric_data_sheet_path = ''
mqtt_based_metric_received = False


class WlLauncherException(Exception):
    """
    Class for WLC runner exceptions
    """
    pass


class WlLauncher(object):
    """
    Launch WLC processes

    """

    def __init__(self,
                 wl_dict,
                 settling_time,
                 metrics_handle, broker, form_device_vm_mgmt_obj):
        """
        Init WLC runner
        :param wl_dict: workload dict created when wlc_bench gets launched holding all attributes of that wl
        :param settling_time: time in secs to wait until app loads
        :param broker: handle to MQTT broker client
        """
        self.module_tag = 'wlc_bench'
        self.wl_list = wl_dict
        self.thrs_kpi_mets = {}
        self.__extract_metric_threshold()

        self.settling_time = settling_time
        self.wl_proc_obj = {}
        self.wl_proc_pids = {}

        self.broker = broker

        self.metrics_handle = metrics_handle

        self.density = 0

        self.wl_status = {}

        self.execution_status = True
        self.form_dev_vm_mgmt_obj = form_device_vm_mgmt_obj
        self.is_local_exe_mode = form_device_vm_mgmt_obj.is_local_exe_mode

        self.topic_appender = '+/+'
        self.topic_error = f"{self.topic_appender}/kpi/error/+"
        self.topic_status = f"{self.topic_appender}/kpi/status"
        self.topic_metric = f"{self.topic_appender}/kpi/metric/+/+"

        self.logs_path = {}
        self.kpi_metrics_data = []

        self.workload_topic_mapping = {
            'p': {},
            'm': {}
        }
        self.log_files = {}

    def initialize(self):
        """
        Initialize runner with topics to subscribe to
        :return: None
        """

        def _on_status_change(topic, payload):
            """
            Status change callback
            :param topic: input topic string
            :param payload: received payload
            :return: disconnect from app if connected msg not received, else continue
            """
            global disconnect, wl_count
            # topic is <app>/<pid>/kpi/status, synbench/122/kpi/status
            # message is {"timestamp":"2021-10-05 16:45:11", "message":"connected"}
            # message is {"timestamp":2021-10-05 16:45:11, "message":"terminated"}
            # message is {"timestamp":"null", "message":"lwt"}
            val = topic.split("/")

            try:
                payload = json.loads(payload)
                logging.info(f"[Received] on : {topic} message: {payload['message']}")

                if payload["message"] != "connected":
                    logging.error(f"Process {val[0]} with parent PID:{val[1]} disconnected from MQTT!")
                    disconnect = True
                    self.execution_status = False
                else:
                    self.wl_status[wl_count] = True

            except json.decoder.JSONDecodeError as ex:
                logging.error(f"Received message not in JSON format. Received payload from"
                              f" process {val[0]} with parent PID:{val[1]} is : {payload}. "
                              f"Exception message is {str(ex)}")
                disconnect = True
                self.execution_status = False

        def _on_kpi_error(topic, payload):
            """
            KPI error callback
            :param topic: input topic string
            :param payload: received payload
            :return: disconnect from app if KPI err msg received, else continue
            """
            global disconnect

            try:
                payload = json.loads(payload)
                logging.debug(f"[Received] on : {topic} message: {payload}")

                # topic is <app_name>/<pid>/kpi/<error,warning etc.>/<error #>, synbench/122/kpi/error/1
                val = topic.split("/")

                logging.error(f"KPI ERROR #{val[4]} detected "
                              f"on process:{val[0]},{val[1]} "
                              f"message: {payload['message']}")
                disconnect = True

            except json.decoder.JSONDecodeError as _:
                logging.error(f"Could not parse raw data: {payload}")

        def _on_kpi_metric_upd(topic, payload):
            """
            KPI error callback
            :param topic: input topic string
            :param payload: received payload
            :return: disconnect from app if KPI err msg received, else continue
            """
            global disconnect, mqtt_based_metric_received

            mqtt_based_metric_received = True
            try:
                payload = json.loads(payload)
                logging.debug(f"[Received] on : {topic} message: {payload}")

                # Topic Template:
                # host_name/wl_type/profile_name/outer_instance/wl_name/inner_instance/kpi/metric/<metrics_id>/value,
                # Eg: native.vm1/measure/indu_hmi-high/1/meida_ai_pipeline/1/kpi/metric/fps/value
                #
                # +===========+===============+====================+==========================+===============+===================+
                # +.Host.Name.+.Workload.Type.+.Profile.Group.Name.+.Grouped.Profile.Instance.+.Workload.Name.+.Workload.Instance.+
                # +===========+===============+====================+==========================+===============+===================+
                val = topic.split("/")

                metric_type = val[-2]
                metric_value = payload

                # appname/p1/kpi/metric/fps/value
                wl_type_map = self.workload_topic_mapping.get(val[-5][0])
                metrics_info = wl_type_map.get(val[-5])

                copped_metrics_info = metrics_info.split("/")
                host_name = copped_metrics_info[0]
                wl_type = copped_metrics_info[1]
                prof_grp = copped_metrics_info[2]
                prof_grp_instance = copped_metrics_info[3]
                wl_name = copped_metrics_info[4]
                metric_instance = copped_metrics_info[5]

                metric_threshold = self.thrs_kpi_mets[host_name][wl_type][prof_grp][wl_name]['metric_threshold'] \
                    .get(metric_type, {})
                min_value = metric_threshold.get('min', None)
                max_value = metric_threshold.get('max', None)
                err_msg = ''

                if min_value and metric_value < min_value:
                    err_msg = f'{metric_type.upper()} value {metric_value} drops below Threshold {min_value}'

                if max_value and metric_value > max_value:
                    err_msg = f'{metric_type.upper()} value {metric_value} raises above Threshold {max_value}'

                self.update_kpi_metric_value(host_name, wl_type, prof_grp, wl_name, prof_grp_instance,
                                             metric_instance, metric_type, metric_value)

                if err_msg:
                    now = datetime.now()
                    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")

                    cur_top = "/".join(topic.split('/')[:-3]) + f'/error/{metric_type}Threshold'
                    json_data = {
                        'timestamp': timestamp,
                        'message': err_msg
                    }
                    raw_payload = json.dumps(json_data)
                    _on_kpi_error(cur_top, raw_payload)

            except json.decoder.JSONDecodeError as _:
                logging.error(f"Could not parse raw data: {payload}")

        try:
            logging.info(f"Subscribe to initial topics with callbacks")
            self.broker.subscribe(self.topic_error, _on_kpi_error)
            self.broker.subscribe(self.topic_status, _on_status_change)
            self.broker.subscribe(self.topic_metric, _on_kpi_metric_upd)
        except Exception as e:
            raise BrokerException(e)

    def run(self):
        """
        Start all subprocesses, call initialize() for init broker with topics
        :return: None
        """
        global wl_count
        self.initialize()

        for host, wl_list in self.wl_list.items():
            if wl_list:
                StarDecorator.double_blocked_print(f"Running proxy workloads on {host}")

            # workload object wl_dict(wl, profile_name, start_cmd, stop_cmd, instances, calculate)
            for grouped_wl in wl_list:
                # no nested sub listed in proxy, so start them directly
                if "proxy" in grouped_wl["type"]:
                    for each_wl in grouped_wl["wl_list"]:
                        each_wl['host'] = host
                        # Passing Group instances as 0 always, since the Proxy workload doesn't support it.
                        self.launch_workloads(each_wl, 'proxy', 0)

        for host, wl_list in self.wl_list.items():
            if wl_list:
                StarDecorator.double_blocked_print(f"Running Measure Workloads on {host}")

            # workload object wl_dict(wl, profile_name, start_cmd, stop_cmd, instances, calculate)
            for grouped_wl in wl_list:
                # no nested sub listed in proxy, so start them directly
                if "proxy" not in grouped_wl["type"]:
                    # there are nested sub lists in measured wl
                    # since we have grouped/conglomerate wls defined
                    # parse through each list and sub list
                    for x in range(grouped_wl["instances"]):
                        grp_name = grouped_wl['type']
                        StarDecorator.double_blocked_print(f"Running measured group instance ({x + 1} "
                                                           f"of {grouped_wl['instances']}) for {grp_name} on {host}")
                        for each_wl in grouped_wl["wl_list"]:
                            each_wl['host'] = host
                            self.launch_workloads(each_wl, grp_name, x)

                    grouped_wl["wkld_density"] = self.density
                    self.density = 0

        if self.wl_proc_obj is not None:
            for k, v in self.wl_proc_obj.items():
                logging.info(f"Created: {len(v)} of {k}")

    def launch_workloads(self, wl, grp_name, grp_instance):
        """
        Method to loop through the workloads and launch in the respective VM based on the configuration with udpated
            MQTT Topic

        :param wl: workload dict from yml file
        :param grp_name: Name of the Workload Group
        :param grp_instance: Instance of the workload group

        :return: None, breaks if KPI error exception encountered
        """
        global wl_count

        wl_name = wl["wl"]
        wl_type = wl["type"]
        profile_name = wl["profile_name"]

        init_cmd = None
        if "init_cmd" in wl and wl["init_cmd"] is not None:
            init_cmd = wl["init_cmd"]

        cmd = wl["start_cmd"]

        instances_num = wl["instances"]
        kpi_window = wl["kpi_window"]
        host = wl.get("host", 'native')
        logs_folder_path = wl.get("logs_path", None)

        host_name_lst = host.split('.')
        host_obj = self.form_dev_vm_mgmt_obj.virt_mgmt_obj_dict.get(host)

        if not host_obj:
            host_obj = self.form_dev_vm_mgmt_obj.virt_mgmt_obj_dict.get(host_name_lst[0])
            if host_obj:
                if len(host_name_lst) > 1:
                    for obj in host_name_lst[1:]:
                        if hasattr(host_obj, 'vm_obj_dict'):
                            host_obj = host_obj.vm_obj_dict.get(obj)
                        else:
                            host_obj = self.form_dev_vm_mgmt_obj.virt_mgmt_obj_dict.get(host)
                else:
                    if hasattr(host_obj, 'sut_obj'):
                        host_obj = host_obj.sut_obj
        else:
            if hasattr(host_obj, 'sut_obj'):
                host_obj = host_obj.sut_obj

        if not host_obj:
            raise Exception(f'Invalid host name is defined for the wl launch in yaml config {host}')

        if not logs_folder_path:
            if host_obj.os_name == 'linux':
                logs_folder_path = f'/home/{host_obj.username}'
            elif host_obj.os_name == 'windows':
                logs_folder_path = f'C:\\Users\\{host_obj.username}\\Desktop'
            elif host_obj.os_name == 'android':
                logs_folder_path = '/storage/self/primary/Documents'
            else:
                raise Exception(f'Invalid OS Name {host_obj.os_name}')

        # create dict holding all data about wls instantiated till now
        # its a dict with lists as values
        # dict(proxy-high: [list of pids], measured-high: [list of pids]

        workload_name = f"{wl_name}-{wl_type}-{profile_name}"
        if f"{workload_name}" not in self.wl_proc_obj:
            self.wl_proc_obj[f"{workload_name}"] = []

        if f"{workload_name}" not in self.wl_proc_pids:
            self.wl_proc_pids[f"{workload_name}"] = {}

        for x in range(instances_num):
            # global count of all workloads started
            wl_count = wl_count + 1
            StarDecorator.double_blocked_print(f"Running Workload instance ({x + 1} of {instances_num}) for {wl_name} "
                                               f"in Host - {host}")
            trigger_cmd = cmd

            out_file = f"{logs_folder_path}/wlc_bench_logs/"
            if host_obj.os_name == 'windows':
                out_file = f"{logs_folder_path}\\wlc_bench_logs_1\\"

            self.logs_path[host_obj.device_tag] = out_file

            mkdir_cmd = f'mkdir {out_file}'
            if host_obj.os_name == 'windows':
                mkdir_cmd = f'cmd.exe /c "{mkdir_cmd}"'

            host_obj.execute(command=mkdir_cmd)

            try:
                # run any init commands if init_cmd key has been set in yml file
                if init_cmd:
                    init_file = f"log_stdout_{workload_name}_wl_{wl_count}_init_cmd.log"
                    init_log_path = os.path.join(logging.get_log_folder_path(), init_file)

                    init_exe_sts = host_obj.execute(command=init_cmd, timeout=200)
                    if not init_exe_sts.get('status', False):
                        logging.error('Failed to execute init command')

                    output = init_exe_sts.get('output', '')
                    if output:
                        self.log_file_write(init_log_path, output)

                    logging.info("Ran workload initialization commands")

                logging.info("Pause subscription on KPI errors channel to handle new WL error spikes")
                self.broker.unsubscribe(self.topic_error)

                if cmd:
                    out_file = f"{out_file}log_stdout_{workload_name}_wl_{wl_count}.log"

                    if cmd.find('-mt') >= 0:
                        trigger_cmd = self.__update_topic_in_cmd_with_req_params(host, wl_type, wl_name, profile_name,
                                                                                 grp_name, grp_instance, x, cmd)

                    # WAR - to Handle the multi commands for android like below example
                    #   am start com.antutu.ABenchMark/com.antutu.ABenchMark.ABenchMarkStart; sleep 5; input tap 32 20
                    if host_obj.os_name == 'android':
                        cmd_sep_idx = trigger_cmd.find(';')
                        temp_cmd = trigger_cmd[:cmd_sep_idx]
                        match = re.findall('.*(com.*)\/', temp_cmd)

                        if match:
                            temp_cmd = match[0]
                        else:
                            logging.warning('Failed to get the app name form the start command, pid parsing might '
                                            'fail!')
                        pid_match_str = self.__get_pat_match_str(temp_cmd)

                    else:
                        pid_match_str = self.__get_pat_match_str(trigger_cmd)

                    if host_obj.os_name == 'windows':
                        pid_match_str = self.__add_escape_chars(pid_match_str)

                        # WAR
                        trigger_cmd = f'cmd.exe /c {trigger_cmd}'

                    cmd_with_log_append = f'{trigger_cmd} '
                    # if host_obj.os_name != 'android':

                    if not self.log_files.get(host, None):
                        self.log_files[host] = []

                    self.log_files[host].append(os.path.normpath(out_file))
                    cmd_with_log_append += f'> {out_file}'

                    logging.info(f"{workload_name} instance: wl_#{wl_count} CMD:{cmd_with_log_append}")
                    wl_exe_sts = host_obj.send_background(command=cmd_with_log_append)
                    if not wl_exe_sts.get('status', False):
                        logging.error(f'Failed to execute WL: {workload_name}')
                        break

                    session_id = wl_exe_sts.get('session_id', None)
                else:
                    logging.warning("No start_cmd specified. Skipping this WL "
                                    f"{workload_name}_wl_{wl_count}")
                    continue

                logging.info(f"Wait for settling time of {self.settling_time}s")
                self.wait(self.settling_time, session_id, host_obj)

                logging.debug(f'Process name to get the PID: {pid_match_str}')
                pid_sts = host_obj.get_pid_of_process(pid_match_str)
                if not pid_sts.get('status', False):
                    logging.error(f'Failed to get PID of {workload_name}')
                    break

                pid_lst = pid_sts.get('pid')

                # append all proc objs to dict
                self.wl_proc_obj[f"{workload_name}"].append(session_id)

                if host not in self.wl_proc_pids[f"{workload_name}"]:
                    self.wl_proc_pids[f"{workload_name}"][host] = {}
                    self.wl_proc_pids[f"{workload_name}"][host]['host_obj'] = host_obj
                    self.wl_proc_pids[f"{workload_name}"][host]['pid'] = []

                self.wl_proc_pids[f"{workload_name}"][host]['pid'].append(pid_lst)

                if wl_count not in self.wl_status:
                    logging.warning(f"Not received 'connected' message from "
                                    f"{workload_name}."
                                    "\tPlease check if workload is connected to the MQTT broker."
                                    "\tCheck log file for any errors."
                                    "\tOr your WL may not be publishing messages on MQTT."
                                    "\tWL Density calculations will thus be incorrect")

                # capture metrics if enabled
                if self.metrics_handle.is_capture_metrics:
                    if not self.metrics_handle.collect_store(self.wl_proc_obj, wl_type):
                        self.metrics_handle.execution_mode = 'With WL'

                        mod_wl_type = wl_type
                        if wl_type.find('measured') == 0:
                            mod_wl_type = 'measured'

                        if not self.metrics_handle.wl_exe_sts.get(host, None):
                            self.metrics_handle.wl_exe_sts[host] = {}

                        if not self.metrics_handle.wl_exe_sts[host].get(mod_wl_type, None):
                            self.metrics_handle.wl_exe_sts[host][mod_wl_type] = 1
                        else:
                            self.metrics_handle.wl_exe_sts[host][mod_wl_type] += 1

                logging.info("Restart subscription on KPI errors channel")
                self.broker.subscribe(self.topic_error, self.broker.subscription_list[self.topic_error])

                logging.info(f"Watch for KPI errors in KPI window duration of: {kpi_window}s")
                self.wait(kpi_window, session_id, host_obj)

                # increment wlc density value if measured wl only - proxy wl not counted for density
                if "measured" in wl_type:
                    self.density = self.density + 1

            except WlLauncherException as e:
                logging.error(e)
                break

            finally:
                time.sleep(1)

    @staticmethod
    def calculate_fps(workload, is_local_exe):
        """
        Calculate avg FPS from wl log file
        :param workload: wl dict from yml file
        :param is_local_exe: Flag to execute the legacy flow to calculate the FPS

        :return mean_fps: avg fps, calculates and print fps as float
        """
        global mqtt_based_metric_received

        avg = []

        # for max_fps, there will always be one measured file to open
        if not mqtt_based_metric_received:
            cur_log_fol_path = logging.get_log_folder_path()
            folder_path = cur_log_fol_path if is_local_exe else os.path.join(cur_log_fol_path, '*')
            path = f"{folder_path}/log_stdout_{workload['wl']}-{workload['type']}-" \
                   f"{workload['profile_name']}_wl_*"

            for filename in glob.glob(path):
                with open(filename) as f:
                    content = f.readlines()
                    for line in content:
                        if "fps." in line:
                            matches = re.findall(r"[+-]?\d+\.\d+", line)
                            if matches:
                                avg.append(float(matches[-1]))
        else:
            if metric_data_sheet_path and os.path.exists(metric_data_sheet_path):
                # Load the xlsx file
                csv_data = pd.read_csv(metric_data_sheet_path)
                req_col = ('Workload Type', 'Profile Group Name', 'KPI Metric Name', 'Average KPI Value')

                # Read the values of the file in the dataframe
                xl_data = pd.DataFrame(csv_data, columns=req_col)

                for idx, wl_data in xl_data.iterrows():
                    fps_sts_dict = wl_data.to_dict(into=dict)
                    wl_type = fps_sts_dict.get(req_col[0])
                    wl_name = fps_sts_dict.get(req_col[1])
                    metric_type = fps_sts_dict.get(req_col[2])
                    if f'{wl_type}_{wl_name}' == workload['type'] and metric_type == 'fps':
                        avg.append(fps_sts_dict.get(req_col[3]))
            else:
                logging.debug('Metric data sheet is not created to calculate max FPS !!')

        if avg:
            logging.debug(f'List of the FPS Value: {avg}')
            mean_fps = statistics.mean(avg)

            logging.info(f"*********************************************************")
            logging.info(f"Max FPS for wl_{workload['type']}"
                         f"_{workload['wl']}-{workload['profile_name']} "
                         f"= {mean_fps:.3f}")
            logging.info(f"*********************************************************")

            return mean_fps
        else:
            logging.warning(f"No FPS Value Found !!")
            return 0

    def wait(self, time_period, process, host_obj):
        """
        Wait for specified time with countdown
        :param time_period: time in secs
        :param process: popen process obj
        :param host_obj: Host device object where the Workload is executed

        :return: None
        """
        global disconnect
        for i in range(1, time_period + 1, 1):
            if disconnect:
                raise WlLauncherException("KPI error encountered. Closing wlc_bench")

            if not host_obj.is_process_running(process):
                logging.error(f"WL Process has ended unexpectedly! Check process log "
                              f"in {logging.get_log_folder_path()} folder. Ending wlc_bench")

                disconnect = True
                self.execution_status = False

            print(f"Wait for {i}", end="\r")
            time.sleep(1)

    def kill(self):
        """
        Kill runner, kill all processes spawned by runner
        :return: None
        """
        global mqtt_based_metric_received

        # terminate all spawned app processes
        for k, v in self.wl_proc_obj.items():
            for proc in v:
                if hasattr(proc, 'communicate'):
                    try:
                        out, err = proc.communicate(timeout=5)
                    except subprocess.TimeoutExpired:
                        if psutil.pid_exists(proc.pid):
                            p = psutil.Process(proc.pid)

                            # terminate child processes as well, if running many cmds through script
                            children = p.children(recursive=True)
                            p.kill()

                            for child in children:
                                child.kill()

                    out, err = proc.communicate()
                else:
                    host_dict = self.wl_proc_pids.get(k, {})
                    for host_name, pid_dict in host_dict.items():
                        with_prv = not host_name.find('.') > 0
                        host_obj = pid_dict.get('host_obj')
                        pid = tuple(pid_dict.get('pid'))
                        logging.debug(f'Killing process - {pid} in Host: {host_name}')
                        try:
                            sts = host_obj.kill_process_with_pid(pid, with_privilege=with_prv)

                            if not sts.get('status', False):
                                logging.error(f'Failed to kill the WL {k}, host {host_name}, pid {pid}')
                        except:
                            pass
                    break

        # terminate any docker containers if spawned, needs stop_cmd param set in yml file
        for host, wl in self.wl_list.items():
            host_name_lst = host.split('.')
            host_obj = self.form_dev_vm_mgmt_obj.virt_mgmt_obj_dict.get(host)

            if not host_obj:
                host_obj = self.form_dev_vm_mgmt_obj.virt_mgmt_obj_dict.get(host_name_lst[0])
                if host_obj:
                    if len(host_name_lst) > 1:
                        for obj in host_name_lst[1:]:
                            if hasattr(host_obj, 'vm_obj_dict'):
                                host_obj = host_obj.vm_obj_dict.get(obj)
                            else:
                                host_obj = self.form_dev_vm_mgmt_obj.virt_mgmt_obj_dict.get(host)
                    else:
                        if hasattr(host_obj, 'sut_obj'):
                            host_obj = host_obj.sut_obj
            else:
                if hasattr(host_obj, 'sut_obj'):
                    host_obj = host_obj.sut_obj

            if not host_obj:
                raise Exception(f'Invalid host name is defined for the wl launch in yaml config {host}')

            for host_wl_list in wl:
                for each_wl in host_wl_list["wl_list"]:
                    if each_wl["stop_cmd"]:
                        logging.debug(f'Executing STOP Command - {each_wl["stop_cmd"]}')
                        host_obj.execute(command=each_wl["stop_cmd"], timeout=60)

        logging.info("Terminated all spawned processes")

        if mqtt_based_metric_received:
            self.__create_metric_xlsx()

    def log_file_write(self, file_path: str, data: str) -> None:
        """
        Method to write the given data to the file

        :param file_path: Required - New file path
        :param data: Required - Data to write

        :return: None
        """
        logging.debug(f'Writing Log file: {file_path}')
        with open(file_path, "w") as file_handler:
            file_handler.write(data)
            file_handler.write("\n")
            file_handler.close()

    def __extract_metric_threshold(self):
        """
        Method to expand the yaml configuration to access the WL metric threshold with Type and Name

        :return: None
        """
        for host, wl_list in self.wl_list.items():
            for wl in wl_list:
                wl_type = wl.get('type')

                if wl_type.find('measured') == 0:
                    wl_type = 'measured'
                # host = each_wl.get('host', 'no host')

                for each_wl in wl["wl_list"]:
                    profiler_type = each_wl.get('type', 'proxy')

                    profile_name = each_wl.get('profile_name', 'profile name')
                    profiler_type = profiler_type.replace(f'measured_', '')

                    wl_name = each_wl.get('wl', 'WL Name')
                    wl_name = f'{wl_name}-{profile_name}'

                    if not self.thrs_kpi_mets.get(host, None):
                        self.thrs_kpi_mets[host] = {}

                    if not self.thrs_kpi_mets[host].get(wl_type, None):
                        self.thrs_kpi_mets[host][wl_type] = {}

                    if not self.thrs_kpi_mets[host][wl_type].get(profiler_type, None):
                        self.thrs_kpi_mets[host][wl_type][profiler_type] = {}

                    if not self.thrs_kpi_mets[host][wl_type][profiler_type].get(wl_name, None):
                        self.thrs_kpi_mets[host][wl_type][profiler_type][wl_name] = {}

                    self.thrs_kpi_mets[host][wl_type][profiler_type][wl_name]['metric_threshold'] = \
                        each_wl.get('metric_threshold', {})

        logging.debug(self.thrs_kpi_mets)

    def update_kpi_metric_value(self, host: str, wl_type: str, profiler_type: str, wl_name: str,
                                profile_grp_instance: str, wl_instance: str, metric_type: str, value: str) -> None:
        """
        Method to update the Received KPI Values to the Dict to create the data sheet in the end

        :logic:
            Update the received KPI value with all required information like host_name, wl_type, profiles_type, wl_name,
                profile_grp_inst, wl_instances, metric type and value.

            data = {'native1.vm1':{'measured':{'indu_hmi_high':{'1':{'media_ai_pipeline- low':{'1':{'fps': '26'}}}}}}}

        :param host: Required - Name of the host where the WL is launched
        :param wl_type: Required - Type of the WL Eg. Proxy/Measured
        :param profiler_type: Required - Type of profiles - indu_hmi_high/indu_hmi_low
        :param wl_name: Required - Name of the WL
        :param profile_grp_instance: Required - Profiler group instances
        :param wl_instance: Required - Work load Instance
        :param metric_type: Required - Metric Type Eg. FPS/Throughput
        :param value: Required - Value of the metric

        :return: None
        """
        self.kpi_metrics_data.append([host, wl_type, profiler_type, profile_grp_instance, wl_name, wl_instance,
                                      metric_type, value])

        logging.debug(f'Added Kpi Data {self.kpi_metrics_data}')

    def __add_escape_chars(self, str_data: str) -> str:
        """
        Method to add the escape character for all special characters like |, +, $, { etc

        :param str_data: Required - Data to which the escape character to be added

        :return: String with escape character added
        """
        str_data = str_data.replace('\\', '\\\\')
        char_list = [r"\|", r"\+", r"\{", r"\}", r"\$", r"\^", r"\@", r"\'"]

        for char in char_list:
            str_data = re.sub(char, f'\\{char}', str_data, flags=re.DOTALL)

        return str_data

    def __get_pat_match_str(self, command: str) -> str:
        """
        Method to get the pattern matcher string from the given command and truncate the string if length is > 150

        :param command: Command to get the pattern matcher and truncate if the string is above 150 char length

        Example:
            Input - /home/kpi/kpi-test/gst/media_ai_pipeline.sh kpi/metric/+/+ 10.34.40.213 420p_1920x1080_2mbps_8b.h265
            Output - /home/kpi/kpi-test/gst/media_ai_pipeline.sh.*kpi/metric/+/+.*10.34.40.213.*420p_1920x1080_2mbps_8b.h265

        :return: Pattern matcher String
        """
        match_cmd = command
        if len(command) > 150:
            near_space = command.find(' ', 145)
            match_cmd = command[:near_space] + '.*'

        match_str = f'.*{".*".join(match_cmd.split())}'
        # match_str = match_str.replace(';', '')

        return match_str

    def __update_topic_in_cmd_with_req_params(self, host: str, wl_type: str, wl_name: str, profile_name: str,
                                              grp_name: str, grp_instance: int, wl_instance: int, cmd: str) -> str:
        """
        Method to get the updated topic name based on args passed

        Topic Template:
            host_name/wl_type/profile_name/outer_instance/wl_name/inner_instance
            Eg: native.vm1/measure/indu_hmi-high/1/meida_ai_pipeline/1

        :param host: Required - Host Name in which the WL is running
        :param wl_type: Required - Workload Type
        :param wl_name: Required - Workload Name
        :param profile_name: Required -Profile Name
        :param grp_name: Required - Group Name
        :param grp_instance: Required - Group Instance
        :param wl_instance: Required - Workload Instance
        :param cmd: Required - Command

        :return: String Updated Command with New Topic
        """
        if wl_type.find('measured') == 0:
            wl_type = 'measured'

        mapping = self.workload_topic_mapping[wl_type[0]]

        upd_wl_name = f'{wl_name}-{profile_name}'
        grp_name = grp_name.replace(f'{wl_type}_', '')

        topic = f'{host}/{wl_type}/{grp_name}/{grp_instance + 1}/{upd_wl_name}/{wl_instance + 1}'

        mat_pat = r'(-mt[:\s]+)([a-zA-Z0-9_]+/\d+)'

        # Sample
        # Input - /home/kpi/kpi-test-suite/gst/media_ai_pipeline.sh -mt abc/123 10.106.47.180
        # Output - [('-mt ', 'abc/123')]
        matched_str = re.findall(mat_pat, cmd)
        if not matched_str:
            raise Exception('Failed to get the user topic from the start command. Topic should be like abc/123!!')

        matched_str = matched_str[0]

        # Assuming 1st argument to the WL script is Topic always
        # Eg: /home/kpi/kpi-test-suite/gst/media_ai_pipeline.sh -mt apps/123 10.34.40.213 false CPU
        user_topic = matched_str[1]
        logging.debug(f'User Topic: {user_topic}')

        topic_count = f'{wl_type[0]}{len(mapping)+1}'
        new_top = f'{wl_name}/{topic_count}'
        mapping[topic_count] = topic

        new_top = f'{matched_str[0]}{new_top}'

        trigger_cmd = re.sub(mat_pat, new_top, cmd)
        logging.debug(f'Updated Topic: Mapping {new_top}: {topic}')
        logging.debug(f'Triggering Command: {trigger_cmd}')

        return trigger_cmd

    def __create_metric_xlsx(self):
        """
        Method to create the Data sheet based on KPI data Received

        :Logic:
            1. Read the dict of KPI metric data captured using run
            2. Create a plain sheet 'kpi_metrics' with all data
            3. Calculate the average KPI values for each instances
            4. Create the summary sheet with average values

        # Format of the XL Data
        # +===========+===============+====================+==========================+===============+===================+
        # +.Host.Name.+.Workload.Type.+.Profile.Group.Name.+.Grouped.Profile.Instance.+.Workload.Name.+.Workload.Instance.+
        # +===========+===============+====================+==========================+===============+===================+

        :return: None
        """
        logging.info('In Creating Metrics XL...')
        global metric_data_sheet_path

        if self.kpi_metrics_data:
            data_sheet_name = f'kpi_metric_data_summary.csv'
            metric_data_sheet_fol = logging.get_log_folder_path()

            if not os.path.exists(metric_data_sheet_fol):
                os.makedirs(metric_data_sheet_fol)

            metric_data_sheet_path = os.path.join(metric_data_sheet_fol, data_sheet_name)
            common_headers_list = ['Host Name', 'Workload Type', 'Profile Group Name', 'Grouped Profile Instance',
                                   'Workload Name', 'Workload Instance', 'KPI Metric Name']
            metric_headers_list = common_headers_list + ['KPI Value']
            summary_headers_list = common_headers_list + ['Average KPI Value']

            row_data = {}
            for idx, row in enumerate(self.kpi_metrics_data):
                row_data[f'row_{idx}'] = row

            metrics_data_frame = pd.DataFrame.from_dict(row_data, orient='index', columns=metric_headers_list)

            groups = metrics_data_frame.groupby(
                by=['Host Name', 'Workload Type', 'Profile Group Name', 'Grouped Profile Instance',
                    'Workload Name', 'Workload Instance', 'KPI Metric Name'], as_index=False)

            summary_data_list = {}
            for grp_name, group_data in groups:
                avg = statistics.mean(group_data.get('KPI Value'))
                first_data = list(group_data.values[0])
                first_data[-1] = avg
                summary_data_list[grp_name] = first_data

            summary_data_frame = pd.DataFrame.from_dict(summary_data_list, orient='index', columns=summary_headers_list)

            # To CSV
            metrics_data_frame.to_csv(os.path.join(metric_data_sheet_fol, f'kpi_metric_data.csv'), index=False)
            summary_data_frame.to_csv(metric_data_sheet_path, index=False)

            logging.info(f'Measurements Data Sheets created successfully: {metric_data_sheet_fol} !')
        else:
            logging.warning(f'No Measurements Data captured !')
