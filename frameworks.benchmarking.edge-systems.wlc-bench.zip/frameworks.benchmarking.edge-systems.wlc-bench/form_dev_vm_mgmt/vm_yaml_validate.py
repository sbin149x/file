#!/usr/bin/env python3
#
# INTEL CONFIDENTIAL
#
# Copyright 2021 (c) Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials, and
# your use of them  is governed by the  express license under which  they were
# provided to you ("License"). Unless the License provides otherwise, you  may
# not  use,  modify,  copy, publish,  distribute,  disclose  or transmit  this
# software or the related documents without Intel"s prior written permission.
#
# This software and the related documents are provided as is, with no  express
# or implied  warranties, other  than those  that are  expressly stated in the
# License.
#
# ----------------------------------------------------------------------------
from star_fw.framework_base.logger.api_intf_logger import LoggerAPI

logging = LoggerAPI(device_tag='wlc_bench')


def validate_vm_yaml(yaml_dict, wlc_mode):
    """
    Validates the Input Yaml config info for the VMs creation and workload instantiation
    :return : none
    """
    gpu_pass = 0
    measured_wklds = 0
    vm_names = []
    sos_name = []
    os_img_paths = []
    pltfrm = ''

    if 'system_configs' in yaml_dict:
        system_configs_data = yaml_dict.get('system_configs', {})

        for dev_name, dev_dict in system_configs_data.items():
            pltfrm = dev_dict.get('platform', '').lower()
            for key, info in dev_dict.items():
                if isinstance(info, dict):
                    vm_names.append(key)
                    os_img_paths.append(info.get('image_path'))

                    if info.get('gpu_passthrough', 0) != 0:
                        gpu_pass += 1
                else:
                    if dev_name not in sos_name:
                        sos_name.append(dev_name)

    mode = yaml_dict.get(wlc_mode, {})

    for key, _ in mode.items():
        if key in ['env_vars', 'loglevel', 'settling_time']:
            continue

        def_host = sos_name + vm_names
        k = key.split('.')[-1]
        if k not in def_host:
            logging.error(f'Workloads are defined for invalid Host {k} which is not defined in system configs '
                          f'{def_host}')
            exit()

        host_wlks = mode.get(key, {})
        if host_wlks.get("measured_wl", None):
            measured_wklds += 1

    validate_yaml_info(pltfrm, gpu_pass, vm_names, os_img_paths, measured_wklds)


def validate_yaml_info(platform, gpu_flag, vm_names, os_image_paths, Number_of_measured_wklds):
    """
    Validate parsed YAML information
    :Param platform: Platform on which Virtualization in exercised
    :param gpu_flag: Number of GPU passthrough / SRIOV flags
    :param vm_names: Names of the VMs to be created
    :param os_image_paths: OS image paths for the VMs
    :Param Number_of_measured_wklds: Number of Measured workloads
    :return : None - Exits if invalid Yaml info found
    """
    # validate duplicate VM names
    for i in vm_names:
        if vm_names.count(i) > 1:
            logging.error('More than 1 VM has same name ... INVALID yaml file')
            exit()

    # validate for Duplicate OS image paths
    for i in os_image_paths:
        if os_image_paths.count(i) > 1:
            logging.error('More than 1 VM has same OS image path ... INVALID yaml file')
            exit()

    # validate for GPU flags
    if (platform == "tgl-u" and gpu_flag > 1):
        logging.error('More than 1 VM has GPU pass through... INVALID yaml file')
        exit()
    # elif (platform == "adl-s"):
    #     max_numv = find_num_sriov_vfs()
    #     if (gpu_flag > int(max_numv)):
    #         logging.error('SRIOV GPU assignments is more than the max_numvfs... INVALID yaml file')
    #         exit()

    if Number_of_measured_wklds > 1:
        logging.error('None or more than 1 VM has measured workload mentioned... INVALID yaml file')
        exit()


def find_num_sriov_vfs():
    """
    finding the total number of SRIOV Virtual functions created in the system.
    :param: None
    :return :max_numvfs: total number of VFs
    """
    max_numvfs = 0
    try:
        f = open("/sys/class/drm/card0/device/sriov_numvfs", "r")
    except IOError:
        logging.error("Error: sriov_numvfs file does not appear to exist.")
        return 0
    max_numvfs = f.read()
    if (int(max_numvfs) > 0):
        logging.info("adl-s platform with SRIOV VF enabled")
    f.close()
    return max_numvfs
