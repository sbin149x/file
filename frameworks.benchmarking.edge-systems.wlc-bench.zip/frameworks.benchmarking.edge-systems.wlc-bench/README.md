# wlc_bench

WLC (workload consolidation) framework for benchmarking and WL density profiling

The overall idea of how wlc_bench fits into our various platform benchmarking efforts 
is documented in this [Wiki](https://wiki.ith.intel.com/display/iotgsysarch/IOTG+System+Architecture+Home)


![WLC Bench](images/wlc_bench.png)


# Architecture to run WLC Bench Outside SUT

WLC bench has support to run outside SUT (SOS) where it can run on some another machine (THM) to have below benefits.
***
    * WLC bench runs from a known good system (Failures are workload failures, not test bench failures) 
    
    * Better scalability/balance across multiple targets
    
    * All SUTs are only running use cases with no extra load of the test bench
    
    * Non-SUT coordinating WL distribution across all targets (Scales to Edge systems orchestration microarchitecture )

The new feature is completely backward compatible and automatically detects whether it is running on SUT(SOS) or on some other machine.

Here is the high-level architecture diagram for Outside SUT mode:


![WLC Bench](images/wlc_bench_off_sut.png)

# General guidelines for new features

Please refer to CONTRIBUTING.md

# Overview

WLC benchmarking and density profiling framework. Instantiates multiple instances 
of workload under test and determines WLC density. Uses MQTT to listen to messages
from workloads under test

# Pre-Requisites

1. Install `mosquitto` MQTT broker
   `sudo apt update -y && sudo apt install mosquitto mosquitto-clients -y`
   
   i. Add the below configuration in `/etc/mosquitto/mosquitto.conf`
        
        allow_anonymous true
        
   ii. run the mosquitto with the config created using `sudo systemctl restart mosquitto`
    
   iii. Make sure it is running using `sudo systemctl status mosquitto` should show `running`
      
2. Your choice of workload-under-test
   
   `wlc_bench` has tested proxy HMI WL - `synbench`
   
   To instantiate `synbench`:
   
   - Clone, Build and Install `synbench` - [synbench](https://github.com/intel-innersource/drivers.gpu.virtualization.synbench/tree/hmi_proxy)
   
        **Note**: `synbench` needs Paho MQTT client libraries to be installed
   
        `sudo apt install openssl libssl-dev && git clone https://github.com/eclipse/paho.mqtt.c.git 
                && cd paho.mqtt.c && make && sudo make install`
   
   - Continue to build/run `synbench` (switch to `hmi_proxy` branch)
   
        **Note**: As part of the new timing code, please set the follow param in `params.txt` to 0
   
       `0           // KPI General: exit on kpi failure (1 = exit, 0 = don't exit)`
   
        **Above step is very important for synbench to run without exiting when errors occur. `synbench` is stopped
        via `wlc_bench` which handles the errors**
                
3. OS tested: Ubuntu 16, 18, 21, Tested using Python3.8

4. Python 3.8, 3.6, 3.9 Python PIP3

**Note**: If integrating new WL into `wlc_bench`, make sure your WL is publishing KPI related messages
on below mentioned MQTT channels. MQTT is the message bus of choice currently

# Install

1. `git clone <this repo>`
2. `cd wlc_bench`
3. `pip3 install -r requirements.txt`
4. `pip3 uninstall star_fw framework_base iotg_virtualization`
5. `pip3 install framework_base=0+unified_vm_abstract_qemu_libvirt -i https://ubit-artifactory-ba.intel.com/artifactory
/api/pypi/star_pip_packages-ba-local/simple/ --extra-index-url https://pypi.org/simple/ --proxy http://proxy-chain.intel.com:911 --no-cache-dir`
6. `pip3 install iotg_virtualization==0+unified_vm_abstract_qemu_libvirt -i https://ubit-artifactory-ba.intel.com
/artifactory/api/pypi/star_pip_packages-ba-local/simple/ --extra-index-url https://pypi.org/simple/ --proxy http://proxy-chain.intel.com:911 --no-cache-dir`

**Note**:
 
1. Please install python requirements using `requirements.txt` so that the right versions are installed
2. Please remove the proxy if it is already set in the setup 

# One time Update in linux VM

To increase SSH max session  

    1. Update the MaxSession to 100 in the below file using `sudo vi /etc/ssh/sshd_config` which will commented by default.
    2. Restart the ssh using `sudo systemctl restart ssh `

# Multiple Independent Display Support

Default configuration assumes single monitor setup on your target platform. Certain RBHE use cases need
a multiple monitor setup and we have enabled these use cases via `sway` compositor and `wlc_bench`

More details, setup instructions in this [Wiki](https://github.com/intel-innersource/frameworks.benchmarking.edge-systems.wlc-bench/wiki/RBHE-Multi-Display-Setup)

If multi monitor setup is not needed, above configuration is not required  

# Configuration file

All system related configuration which are independent of WLs are under `system_config` section 

    1. wlc_bench will consider the execution is from SUT in following scenarios
        i. If no system config is added
        ii. If sytem config is added with no information for the native
        iii. If the native informations are same as the local machine         
        
    2. configurations for outside SUT Run
        i. MQTT Broker will run in the Test Host Machine (THM)
        ii. MQTT Broker IP Address should be passed with keyword argument -mb <ip address of THM>
        iii. MQTT Topic Name should be passed with keyword argument -mt <topic Name> with appname/id, Eg. synbench/123

In the below Example:

native1: user defined name for native.(user can choose to provide some other name). The same name should be
used define proxy WLs,measured WLs and system metric for that particular setup.

vm1/vm2: user defined name for vms(user can choose to provide some other name). The same name should be used define
 proxy WLs,measured WLs and system metric for that particular setup.
(The format to use vm is <native name>.<vm name> (like "native1.vm1")).

```
system_configs:
  native1:
    host: '10.106.47.91'       # native/SUT host name or ip address
    user: "xxxx"               # username of native
    password: "xxxx"           # password of native
    os: "linux"                # OS NAme
    launch_vm: True            # Launch_vm is global flag for native to create vm. This is true by default (if
 commented here) and user can make it False, if they do not want to launch VM. there is one more flag inside each vms if
 you want to control individual VMs and that takes precedence over this flag for that particular VM
    platform: 'ADL-S'          # Platform Name of the SOS
    vm_launch_tool: 'qemu'     # global varibale for launch tool to launch vm. options are qemu and libvirt
    vm1:
      #host: <ip of vm>           # optional - required only for libvirt if you are manual vm launch
      user: "ubuntu"              # username of native
      password: "1234"            # password of native
      os: "linux"                 # VM OS name
      port: "2222"                # port of vm for doing ssh to it
      image_path: '/home/hspe/vm/ubuntu.qcow2'  # vm image location on SOS/SUT
      cpu: 6                      # number of CPUs to allocate for VM
      ram: '4GB'                  # ram size of VM. it shoudl be in GB or KB or MB like 4GB or 4096MB
      bios_type: 'UEFI'           # VM bios type it should be BIOS or UEFI
      gpu_passthrough: 1          # GPU Driver support
      vm_launch_tool: 'libvirt'  # optional - This flag will take the priority if you do not want to use the global
 tool defined for native
      libvirtxml: '/home/user/xyz.xml'      # optional -Path of the XML template to be used, This is required only in
 case if libvirt
 based VM Launch.
    vm2:
      user: "tester"              # username of native
      password: "1234"            # password of native
      os: "windows"               # OS Name
      port: "1111"
      image_path: '/home/hspe/vm/win10_enterprise.qcow2'
      bios_type: 'bios'
      cpu: 4
      ram: '4GB'
      zc_build: "c:\\ZCBuild_201_Debug" # optional - zero copy image path on windows vm to enable zero copy driver
 after vm launch due to current issue with windows VM image
      gpu_passthrough: 1
    vm3:
      os: "android"       # OS NAme
      port: "5555"
      image_path: '/home/hspe/vm/caas.img'
      bios_type: 'uefi' #BIOS/UEFI
      cpu: 2
      ram: '4GB'
      gpu_passthrough: 0
```

Currently wlc_bench supports a single mode `breakpoint_serial`. 

This mode helps run multiple instances of the workload serially and 
helps determine max density i.e max number of workloads that can be run ona given platform

It can also print maximum FPS of a single workload. More details in section below

The file defines two types of workload:

1. Proxy WL - Typically one instance of this is run. Ex: on screen synbench instance
2. Conglomerate Measured WL -  Typically `m x n` instances of these are run where m = # of rounds of a particular grouped
   profile you want to run. n = # of times a particular workload inside that profile 

Each workload has a monitoring window called `kpi_window` in the yml file which indicates how long in seconds
to monitor each workload for KPI errors on the message bus before spawning a new workload

There is a common param called `settling_time` in the yml file which indicates the time in seconds given to a 
workload to settle down before we begin capturing/measuring KPIs

The framework helps determine how many workloads can be spawned while 
maintaining the KPIs of the workloads under test

## Env variables

Set all env variables that a workload (e.g. synbench) needs in the `env_vars` key in the YML file. If none,
keep list empty. `env_vars: []`

```
Ex: env_vars: [ DESTDIR=/home/synbench, OTHERVAR=othervalue]
```

## Init command, Start command, Stop command

The configuration file supports 3 types of commands for a workload:

All 3 commands supports following three formats:
1. Single shell command. `python run.py`
2. Piped commands `python run1.py && python run2.py`
3. Path to a shell script containing multiple commands. `./somescript.sh`

1. `init_cmd`: Any initialization commands to be done before workload begins
2. `start_cmd`: Fully qualified command to start a workload 
3. `stop_cmd`: Any commands needed to stop the workload (this is used mainly for dockerized workloads,
    workloads started natively can keep this as `null`)

```
    {
        wl: synbench,
        profile_name: low,
        init_cmd: /home/sk/run_synbench_init.sh OR any other shell command,
        start_cmd: /home/synbench/synbench -mt abc/123 -mb mqtt_ip /home/params/low.txt,
        stop_cmd: null,
        instances: 1,
        kpi_window: 20
    }
```

## Workload definitions

##### Current implementation will support old yaml format and it is fully backward compatible

### Proxy workload

Define all your static workloads inside the `wl_list: ` parameter one after the other

```
native1.vm1:
    proxy_wl:
        wl_list:
          [
            {
              wl: synbench,
              profile_name: low,
              init_cmd: null,
              start_cmd: /home/synbench/synbench -mt mqtt_topic_name -mb mqtt_ip /home/params/low.txt,
              stop_cmd: null,
              instances: 1,
              kpi_window: 20
            },
            {
              wl: ai,
              profile_name: low,
              init_cmd: null,
              start_cmd: /home/ai/ai /home/params/low.txt,
              stop_cmd: null,
              instances: 1,
              kpi_window: 20
            }
          ]
```

### Conglomerate measured workloads

Bench now supports defining workload profiles for measured workloads. This means you can define a class of workloads
which you want to use for your measurements, WL density calculations.

Ex: Let's say we want to define a `indu_cmc_hmi_high` profile where we want to understand how much residual AI is left when
we start 2 of AI-low and 3 of AI-mid in the measured section.

An example configuration will look like so:

```
native1.vm1:
    measured_wl:
      indu_cmc_hmi_high:
    
          calculate: wkld_density
          instances: 1
          wl_list:
          [
            {
              wl: ai-low,
              profile_name: low,
              init_cmd: null,
              start_cmd: /home//ai-low -mt mqtt_topic_name -mb mqtt_ip /home/params/low.txt,
              stop_cmd: null,
              instances: 2,
              kpi_window: 20
            },
            {
              wl: ai-mid,
              profile_name: mid,
              init_cmd: null,
              start_cmd: /home/ai-mid -mt mqtt_topic_name -mb mqtt_ip /home/params/mid.txt,
              stop_cmd: null,
              instances: 3,
              kpi_window: 20,
              target_fps: 30
            }
          ]

This will calculate wkld_density by running one round of (2 AI-low + 3 AI-mid). If you need any proxy workloads in 
conjunction, define them as you would in the proxy_wl section. 
You can manually specify the target_fps for your measured workload. This is very efficient when you have the
max_fps calculate method to obtain accurate theoretical density numbers.

Similar profiles can be created based on use case requirement like retial POS etc. 
      
```

## WLC Bench calculations

Bench supports two calculations in the conglomerate `measured_wl` section:
`calculate: max_fps or wkld_density`

-  `max_fps` calculates and prints the max FPS for that particular measured workload if the value is set.
This feature is same as the "max" mode used previously where framework prints out MAX FPS for an unconstrained
workload. `max_fps` also requires only one WL to be defined in the `wl_list` section. Throws an error if `instances` > 1

This is useful when trying to find max FPS for workloads to run unconstrained (for example synbench with no vsync)

**Note**: For `max_fps`, all the proxy WL are also run if they are set, so if you wanted to calculate max_fps without proxy
, comment out the proxy wl section

**Note**: To run proxy workload in parallel when calculating `max_fps` for a measured wl, example yaml file below

``` 
Ex: proxy wl in parallel while running a max_fps measured_wl
native1.vm1:
    proxy_wl:
        [
          {
            wl: synbench,
            # please give the profile_name below for correct log files to get generated
            profile_name: high,
            init_cmd: null,
            start_cmd: /home/sanjana/gfx/synbench/synbench -mt mqtt_topic_name -mb mqtt_ip
              /home/sanjana/gfx/synbench/params/intel_indu_hmi_high_profile.txt,
            stop_cmd: null,
            instances: 1,
            kpi_window: 20
          }
     
        ]
 
    measured_wl:
        indu_hmi_high:
          calculate: max_fps,
          instances: 1,
    
          wl_list:
            [
              {
                wl: synbench,
                # please give the profile_name below for correct log files to get generated
                profile_name: high,
                init_cmd: null,
                start_cmd: /home/sanjana/gfx/synbench/synbench -mt mqtt_topic_name -mb mqtt_ip
                  /home/sanjana/gfx/synbench/params/intel_indu_hmi_high_profile.txt,
                stop_cmd: null,
                instances: 1,
                kpi_window: 20
              }
            ]
```
 
- `wkld_density` calculates the max number of **measured workloads** that can be run serially along with the
proxy workloads.

    So, if we run 1 proxy, and Bench can run 3 measured wl can run successfully; 
WLC density will now be printed as 3 since it wont count the proxy


Some examples of using `max_fps or wkld_density`

``` 
Ex 1: measured_wl:
    indu_hmi_high:
      calculate: max_fps,
      instances: 1,

      wl_list:
        [
          {
            wl: synbench,
            profile_name: high,
            init_cmd: null,
            start_cmd: /home/sanjana/gfx/synbench/synbench -mt mqtt_topic_name -mb mqtt_ip
              /home/sanjana/gfx/synbench/params/intel_indu_hmi_high_profile.txt,
            stop_cmd: null,
            instances: 1,
            kpi_window: 20,
            calculate: max_fps
          }
        ]
    
Will output at the end:

[2022-01-19 14:11:14,559] [INFO] [wlc_bench] [wlc_bench.main]: *********************************************************
[2022-01-19 14:11:14,560] [INFO] [wlc_bench] [wlc_bench.main]: wlc_bench execution status: SUCCESS
[2022-01-19 14:11:14,560] [INFO] [wlc_bench] [wlc_bench.main]: Max FPS for measured_indu_hmi_high = 1676.336
[2022-01-19 14:11:14,560] [INFO] [wlc_bench] [wlc_bench.main]: Theoretical WLC Density: N.A
[2022-01-19 14:11:14,561] [INFO] [wlc_bench] [wlc_bench.main]: *********************************************************
[2022-01-19 14:11:14,561] [INFO] [wlc_bench] [wlc_bench.main]: Done

Ex 2: measured_wl:
    indu_hmi_high:
      calculate: wkld_density,
      instances: 1,
      wl_list:
        [
          {
            wl: synbench,
            profile_name: high,
            start_cmd: /home/sanjana/gfx/synbench/synbench -mt mqtt_topic_name -mb mqtt_ip
              /home/sanjana/gfx/synbench/params/intel_indu_hmi_low_profile.txt,
            stop_cmd: null,
            instances: 10,
            kpi_window: 20,
          }
        ]
    
Will output at the end:

[2022-01-19 14:11:14,559] [INFO] [wlc_bench] [wlc_bench.main]: *********************************************************
[2022-01-19 14:11:14,560] [INFO] [wlc_bench] [wlc_bench.main]: wlc_bench execution status: SUCCESS
[2022-01-19 14:11:14,560] [INFO] [wlc_bench] [wlc_bench.main]: Theoretical WLC Density: measured_indu_hmi_high = 4
[2022-01-19 14:11:14,561] [INFO] [wlc_bench] [wlc_bench.main]: *********************************************************
[2022-01-19 14:11:14,561] [INFO] [wlc_bench] [wlc_bench.main]: Done
```

## Message bus

The framework requires Mosquitto broker to be up and running to receive KPI
messages from the workload under test. The broker is assumed to be localhost for
all current configurations

The framework connects to the the broker, subscribes to certain pre-defined topics 
and listens for error messages. If it sees one, then breaks from the framework 
loop and reports the WL density number

Ex: Workload under test: `synbench`

1. After `synbench` starts up for the first time, sends "connected" message on `synbench/<PID>/kpi/status`
 
2. `synbench` publishes KPI error messages on topic: `synbench/<PID>/kpi/error/<KPI error#>`

3. Framework subscribes to this and reports if errors are detected

**Note:**: If synbench is NOT publishing MQTT messages/synbench is NOT connected to the broker; wlc_bench
will log "warning" messages. It wont break from the bench app because, there maybe other workloads which don't
necessarily report messages on MQTT. This is only a warning message to the user
``` 
"Not received connected message from workload. Please check if workload is connected to the MQTT broker.
 Density calculations will be incorrect"
```

## Adding new workloads to WLC Bench

For any new workload to be run as part of Bench framework, following criteria must be met:

1. Once the workload makes the connection to the MQTT broker, publish following message:

```
Topic Name: <your app name>/<pid of your app>/kpi/status 
Payload: 
{
"timestamp": "2021-08-19 09:41:22",
"message": "connected"
}

```

2. Any sudden termination to MQTT broker, publish following message:

```
Topic Name: <your app name>/<pid of your app>/kpi/status 
{
"timestamp": "2021-08-19 09:41:22",
"message": "terminated"
}

```

3. Maintain LWT message on your client connection so that unexpected disconnections can be communicated to Bench:

```
Topic Name: <your app name>/<pid of your app>/kpi/status 
{
"timestamp": "null",
"message": "lwt"
}

```

4. Next, workload is expected to be calculating the KPIs for success or failure. Ex: Refer to the `evaluate_kpis()` function in 
`synbench-hmi_proxy branch`

5. For example, let's assume workload is calculating two types of KPIs: KPI error 1 and KPI error 2

6. If any of the above errors are seen, the error details are published on these topics:

```
Topic Name: <your app name>/<pid of your app>/kpi/error/<kpi error #>
Payload: Your KPI error message

Ex: synbench/111/kpi/error/1
Payload:
{
"timestamp": "2021-08-19 09:41:22",
"message": "your error message here"
}


Ex: synbench/111/kpi/error/2
Payload:
{
"timestamp": "2021-08-19 09:41:22",
"message": "your error message here"
}

```

7. Next, open `wlc_config.yaml` and give appropriate values to the `proxy_wl`, `measured_wl` sections

8. Start `wlc_bench`

`wlc_bench` then takes care of listening to these error messages, aggregating results and calculating workload density numbers

**Note**: If workload sends `terminated` or if Bench receives `lwt` messages on the `status` channel, wlc_bench execution
is stopped as this indicates unexpected termination of one of the proxy or measured workloads

# Dockerized Applications

The framework has the capability to start dockerized workloads. The only requirement is developers/users
create a shell script which invokes their dockerized application.

Once that is ready, one can specify the shell script command to the same `start_cmd` parameter. Now since, the 
shell script spawns docker containers, the containers don't exit if the shell script exits.

So to gracefully close all your application containers, one can specify the stop command via `stop_cmd` parameter
in the yml file.

Ex: We have created a dockerized version of `synbench` - [docker_synbench](https://github.com/intel-innersource/containers.docker.edge-systems.synbench)

In the `scripts/` folder of this repo, there's `run_container.sh` which can be used to launch `synbench` as containers
via `wlc_bench`

The script `run_synbench_container.sh` takes one parameter. Either `<full path to params file> OR stop`. Former will start
synbench as a container and the latter will shutdown/close all spawned containers

For new workloads (AI, RT etc.) - as long as a script is created similarly, one should be able to launch their 
applications as docker containers

``` 
Ex: start synbench as containers

# put all env variables you want to set for each of your workloads
  env_vars: [
      DESTDIR=/home/sanjana/gfx/synbench
    ]
    native1.vm1:
      # proxy wl details, typically 1 - static workload
      proxy_wl:
        wl_list:
        [
          {
            wl: docker_synbench,
            # specify profile_name below for correct log files to get generated
            profile_name: high-onscreen,
            init_cmd: null,
            start_cmd: ./run_container.sh /home/sanjana/gfx/synbench/params/intel_indu_hmi_high_profile.txt,
            stop_cmd: ./run_container.sh stop,
            instances: 1,
            kpi_window: 20
          }
        ]
    
      # measured wl details, typically 1 or many
      # 2 calculations are supported for measured_wl: max fps, density
      # max fps = max fps for a unconstrained workload specified in the measured_wl: start_cmd
      # max density = max density when n number of measured_wl are run
      measured_wl:
        indu_hmi_high:
          calculate: wkld_density,
          instances: 1,
          wl_list:
            [
              {
                wl: docker_synbench,
                # specify profile_name below for correct log files to get generated
                profile_name: high-offscreen,
                init_cmd: null,
                start_cmd: ./run_container.sh /home/sanjana/gfx/synbench/params/intel_indu_hmi_high_profile.txt,
                stop_cmd: ./run_container.sh stop,
                instances: 10,
                kpi_window: 20,
              }
            ]

```

# System Metrics

All the system configs and tools used to collect metrics are present in `./wlc_config.yaml`
in the section `system_metrics`

If `system_metrics:measure is True`, only then the measurement tools are run. Else keep `False`

**Note**: If a particular tool is not installed on the system, it skips and captures the ones available

## Root password

This section is hidden. If it is included in the wlc config file, under system metrics, when
you use system metrics it will run all the tools that require sudo access whithout asking for
the root password. The password specified here will be used instead.

**Note**: For example you can specify `root_pass: <the root password of the DUT system>`

## Tools

1. CPU - `top`. `top` tool should be present by default on any Linux system

2. GPU - `intel_gpu_top`. To install, run `sudo apt install intel-gpu-tools -y`

3. power - `socwatch`. To install: [Wiki here](https://wiki.ith.intel.com/display/IOTGEBP/CMC+use-case+on+Graphics+Component)

4. power from PDU. Connect external PDU to DUT to capture power values. The PDU values
   need to be configured in yml file. Keep `pdu:use_pdu as False` to skip PDU metrics

SoCWatch captures SOC Avg Power, SOC Total Power and Total Memory Bandwidth

All captured metrics/logs can be found in `logs` folder. `system_metrics.xlsx` stores
metrics captured per workload

**Note**: While testing, we noticed `intel_gpu_top` reporting differently on different platforms. 
If you are NOT seeing GPU Render values, please change this line 

`system_utils.py: gpu_render = gpu_line.split()[7]` to `gpu_render = gpu_line.split()[4]`
`

# Run

1. Configure `wlc_config.yml` file as per your requirements

2. `python3 wlc_bench.py wlc_config.yml`
   
   `breakpoint_serial` runs by default. No need to specify additional parameters other than YML file
   
3. Executes and reports WLC density number or Max FPS at the end

**Note**: stdout logs of all spawned processes are stored in `logs/` folder

# Sample Output

```
Snippet of file
python3.8 wlc_bench.py wlc_config.yaml

breakpoint_serial:
# run workloads serially, report wl density
breakpoint_serial:

# put all env variables you want to set for each of your workloads
  env_vars: [
      DESTDIR=/home/sanjana/gfx/synbench
    ]
    native1.vm1:
      # proxy wl details, typically 1 - static workload
      proxy_wl:
        wl_list:
        [
          {
            wl: docker_synbench,
            # specify profile_name below for correct log files to get generated
            profile_name: high-onscreen,
            init_cmd: null,
            start_cmd: /home/sanjana/gfx/synbench/synbench
                  /home/sanjana/gfx/synbench/params/intel_indu_hmi_high_profile.txt,
            stop_cmd: null,
            instances: 1,
            kpi_window: 20
          }
        ]

      # measured wl details, typically 1 or many
      # 2 calculations are supported for measured_wl: max fps, density
      # max fps = max fps for a unconstrained workload specified in the measured_wl: start_cmd
      # max density = max density when n number of measured_wl are run
      measured_wl:
        indu_hmi_high:
          calculate: wkld_density,
          instances: 1,
          wl_list:
            [
              {
                wl: docker_synbench,
                # specify profile_name below for correct log files to get generated
                profile_name: high-offscreen,
                init_cmd: null,
                start_cmd: /home/sanjana/gfx/synbench/synbench
                  /home/sanjana/gfx/synbench/params/intel_indu_hmi_high_off_profile.txt,
                stop_cmd: null,
                instances: 1,
                kpi_window: 20,
              }
            ]
```

```
Output

sudo python3 wlc_bench.py wlc_config_outside_sut.yaml
[2022-01-19 20:15:52,243] [INFO] [wlc_bench] [yml_parser.parse]: Runner YML file wlc_config_outside_sut.yaml loaded, will run in mode:breakpoint_serial
[2022-01-19 20:15:52,243] [INFO] [wlc_bench] [wlc_bench.main]: Setting env variable: DESTDIR=C:\synbench\synbench-hmi\x64\Release\
[2022-01-19 20:15:52,243] [INFO] [wlc_bench] [form_device.create_multiple_dev_objects]: In Create Multiple device Objects...
[2022-01-19 20:15:52,244] [INFO] [wlc_bench] [form_device.create_dev_obj]: In create Device Object - {'_': {}, 'is_vm': False, 'is_connection_req': True, 'port': '22', 'password': 'root@123', 'user': 'hspe', 'host': '10.106.47.91', 'intf_type': 'ssh', 'os': 'linux', 'dev_name': 'native1'}
[2022-01-19 20:15:52,247] [INFO] [native1] [platforms_base.add_test_interface]: Test interface object created successfully - ssh to native1
[2022-01-19 20:15:52,248] [INFO] [native1] [ssh_interface.connect]: IN CONNECT with hostname 10.106.47.91, username hspe, port 22, timeout 120
[2022-01-19 20:15:56,441] [INFO] [native1] [ssh_interface.connect]: SSH Connection Established
[2022-01-19 20:15:56,442] [INFO] [native1] [platforms_base.connect_test_interface]: Test interface connected successfully
[2022-01-19 20:15:56,443] [INFO] [wlc_bench] [form_device.create_dev_obj]: In create Device Object - {'_': {'linked_to': 'native1'}, 'is_vm': True, 'is_connection_req': True, 'port': '2222', 'password': '1234', 'user': 'ubuntu', 'host': '10.106.47.91', 'intf_type': 'ssh', 'os': 'linux', 'dev_name': 'vm1'}
[2022-01-19 20:15:56,447] [INFO] [vm1] [platforms_base.add_test_interface]: Test interface object created successfully - ssh to vm1
[2022-01-19 20:15:56,448] [INFO] [vm1] [ssh_interface.connect]: IN CONNECT with hostname 10.106.47.91, username ubuntu, port 2222, timeout 120
[2022-01-19 20:16:00,585] [INFO] [vm1] [ssh_interface.connect]: SSH Connection Established
[2022-01-19 20:16:00,586] [INFO] [vm1] [platforms_base.connect_test_interface]: Test interface connected successfully
[2022-01-19 20:16:00,589] [INFO] [wlc_bench] [broker.__init__]: Connected to MQTT broker: 10.106.47.180 on port: 1883
[2022-01-19 20:16:00,590] [INFO] [wlc_bench] [wl_launcher.initialize]: Subscribe to initial topics with callbacks
[2022-01-19 20:16:00,591] [INFO] [wlc_bench] [wl_launcher.run]: ========================================
[2022-01-19 20:16:00,591] [INFO] [wlc_bench] [wl_launcher.run]:  Running proxy workloads on native1.vm1
[2022-01-19 20:16:00,592] [INFO] [wlc_bench] [wl_launcher.run]: ========================================
[2022-01-19 20:16:00,592] [INFO] [wlc_bench] [wl_launcher.run]: ==========================================
[2022-01-19 20:16:00,592] [INFO] [wlc_bench] [wl_launcher.run]:  Running Measure Workloads on native1.vm1
[2022-01-19 20:16:00,592] [INFO] [wlc_bench] [wl_launcher.run]: ==========================================
[2022-01-19 20:16:00,593] [INFO] [wlc_bench] [wl_launcher.run]: =================================================================================
[2022-01-19 20:16:00,593] [INFO] [wlc_bench] [wl_launcher.run]:  Running measured group round (1 of 1) for measured_indu_hmi_high on native1.vm1
[2022-01-19 20:16:00,593] [INFO] [wlc_bench] [wl_launcher.run]: =================================================================================
[2022-01-19 20:16:00,594] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: =============================================================================
[2022-01-19 20:16:00,594] [INFO] [wlc_bench] [wl_launcher.create_subprocess]:  Running Workload round (1 of 1) for media_ai_pipeline in Host - native1.vm1
[2022-01-19 20:16:00,594] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: =============================================================================
[2022-01-19 20:16:00,595] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: Pause subscription on KPI errors channel to handle new WL error spikes
[2022-01-19 20:16:00,595] [INFO] [wlc_bench] [broker.unsubscribe]: Unsubscribed from topic: +/+/kpi/error/+
[2022-01-19 20:16:00,595] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: media_ai_pipeline-measured_indu_hmi_high-low instance: wl_#1 CMD:/home/kpi/kpi-test-suite/gst/media_ai_pipeline.sh kpi/metric/+/+ 10.106.47.180 rtsp://10.34.42.14:8554/cross_road_420p_1920x1080_2mbps_8b.h265 1 false tiny_yolo_v2 resnet-50-tf CPU > /home/ubuntu/wlc_bench_logs/log_stdout_media_ai_pipeline-measured_indu_hmi_high-low_wl_1.log
[2022-01-19 20:16:00,608] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: Wait for settling time of 5s
[2022-01-19 20:16:05,656] [WARNING] [wlc_bench] [wl_launcher.create_subprocess]: Not received 'connected' message from media_ai_pipeline-measured_indu_hmi_high-low.    Please check if workload is connected to the MQTT broker.        Check log file for any errors.  Or your WL may not be publishing messages on MQTT.      WL Density calculations will thus be incorrect
[2022-01-19 20:16:05,657] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: Restart subscription on KPI errors channel
[2022-01-19 20:16:05,657] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: Watch for KPI errors in KPI window duration of: 10s
[2022-01-19 20:16:16,681] [INFO] [wlc_bench] [wl_launcher.run]: Created: 0 of synbench_proxy-proxy-low
[2022-01-19 20:16:16,682] [INFO] [wlc_bench] [wl_launcher.run]: Created: 1 of media_ai_pipeline-measured_indu_hmi_high-low
[2022-01-19 20:16:17,675] [INFO] [wlc_bench] [broker.stop]: Disconnected from MQTT broker
[2022-01-19 20:16:17,675] [INFO] [wlc_bench] [wlc_bench.main]: Please wait for all processes to gracefully terminate and produce log files. ctrl+c not recommended
[2022-01-19 20:16:17,896] [INFO] [wlc_bench] [wl_launcher.kill]: Terminated all spawned processes
[2022-01-19 20:16:17,897] [INFO] [vm1] [ssh_interface.copy_file_to_or_from_target]: Copy From SUT to HOST
[2022-01-19 20:16:17,950] [INFO] [vm1] [ssh_interface.__download]: Download of file from remote server successful
[2022-01-19 20:16:19,053] [INFO] [wlc_bench] [wlc_bench.main]: Done
[2022-01-19 20:16:19,054] [INFO] [native1] [platforms_base.close]: Close in Base Platform
[2022-01-19 20:16:19,054] [INFO] [native1] [platforms_base.close]: Closing Primary Interface
[2022-01-19 20:16:19,056] [INFO] [vm1] [platforms_base.close]: Close in Base Platform
[2022-01-19 20:16:19,057] [INFO] [vm1] [platforms_base.close]: Closing Primary Interface
hspe@BA02_ADL_NUC:~/SRG/only_no_sut$ sudo python3 wlc_bench.py wlc_config_outside_sut.yaml
[2022-01-19 20:18:14,737] [INFO] [wlc_bench] [yml_parser.parse]: Runner YML file wlc_config_outside_sut.yaml loaded, will run in mode:breakpoint_serial
[2022-01-19 20:18:14,737] [INFO] [wlc_bench] [wlc_bench.main]: Setting env variable: DESTDIR=C:\synbench\synbench-hmi\x64\Release\
[2022-01-19 20:18:14,737] [INFO] [wlc_bench] [form_device.create_multiple_dev_objects]: In Create Multiple device Objects...
[2022-01-19 20:18:14,738] [INFO] [wlc_bench] [form_device.create_dev_obj]: In create Device Object - {'_': {}, 'is_vm': False, 'is_connection_req': True, 'port': '22', 'password': 'root@123', 'user': 'hspe', 'host': '10.106.47.91', 'intf_type': 'ssh', 'os': 'linux', 'dev_name': 'native1'}
[2022-01-19 20:18:14,741] [INFO] [native1] [platforms_base.add_test_interface]: Test interface object created successfully - ssh to native1
[2022-01-19 20:18:14,742] [INFO] [native1] [ssh_interface.connect]: IN CONNECT with hostname 10.106.47.91, username hspe, port 22, timeout 120
[2022-01-19 20:18:18,937] [INFO] [native1] [ssh_interface.connect]: SSH Connection Established
[2022-01-19 20:18:18,938] [INFO] [native1] [platforms_base.connect_test_interface]: Test interface connected successfully
[2022-01-19 20:18:18,939] [INFO] [wlc_bench] [form_device.create_dev_obj]: In create Device Object - {'_': {'linked_to': 'native1'}, 'is_vm': True, 'is_connection_req': True, 'port': '2222', 'password': '1234', 'user': 'ubuntu', 'host': '10.106.47.91', 'intf_type': 'ssh', 'os': 'linux', 'dev_name': 'vm1'}
[2022-01-19 20:18:18,943] [INFO] [vm1] [platforms_base.add_test_interface]: Test interface object created successfully - ssh to vm1
[2022-01-19 20:18:18,944] [INFO] [vm1] [ssh_interface.connect]: IN CONNECT with hostname 10.106.47.91, username ubuntu, port 2222, timeout 120
[2022-01-19 20:18:23,101] [INFO] [vm1] [ssh_interface.connect]: SSH Connection Established
[2022-01-19 20:18:23,102] [INFO] [vm1] [platforms_base.connect_test_interface]: Test interface connected successfully
[2022-01-19 20:18:23,107] [INFO] [wlc_bench] [broker.__init__]: Connected to MQTT broker: 10.106.47.180 on port: 1883
[2022-01-19 20:18:23,108] [INFO] [wlc_bench] [wl_launcher.initialize]: Subscribe to initial topics with callbacks
[2022-01-19 20:18:23,109] [INFO] [wlc_bench] [wl_launcher.run]: ========================================
[2022-01-19 20:18:23,109] [INFO] [wlc_bench] [wl_launcher.run]:  Running proxy workloads on native1.vm1
[2022-01-19 20:18:23,109] [INFO] [wlc_bench] [wl_launcher.run]: ========================================
[2022-01-19 20:18:23,110] [INFO] [wlc_bench] [wl_launcher.run]: ==========================================
[2022-01-19 20:18:23,110] [INFO] [wlc_bench] [wl_launcher.run]:  Running Measure Workloads on native1.vm1
[2022-01-19 20:18:23,110] [INFO] [wlc_bench] [wl_launcher.run]: ==========================================
[2022-01-19 20:18:23,111] [INFO] [wlc_bench] [wl_launcher.run]: =================================================================================
[2022-01-19 20:18:23,111] [INFO] [wlc_bench] [wl_launcher.run]:  Running measured group round (1 of 1) for measured_indu_hmi_high on native1.vm1
[2022-01-19 20:18:23,111] [INFO] [wlc_bench] [wl_launcher.run]: =================================================================================
[2022-01-19 20:18:23,112] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: =============================================================================
[2022-01-19 20:18:23,112] [INFO] [wlc_bench] [wl_launcher.create_subprocess]:  Running Workload round (1 of 1) for media_ai_pipeline in Host - native1.vm1
[2022-01-19 20:18:23,112] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: =============================================================================
[2022-01-19 20:18:23,112] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: Pause subscription on KPI errors channel to handle new WL error spikes
[2022-01-19 20:18:23,113] [INFO] [wlc_bench] [broker.unsubscribe]: Unsubscribed from topic: +/+/kpi/error/+
[2022-01-19 20:18:23,113] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: media_ai_pipeline-measured_indu_hmi_high-low instance: wl_#1 CMD:/home/kpi/kpi-test-suite/gst/media_ai_pipeline.sh kpi/metric/+/+ 10.106.47.180 rtsp://10.34.42.14:8554/cross_road_420p_1920x1080_2mbps_8b.h265 1 false tiny_yolo_v2 resnet-50-tf CPU > /home/ubuntu/wlc_bench_logs/log_stdout_media_ai_pipeline-measured_indu_hmi_high-low_wl_1.log
[2022-01-19 20:18:23,117] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: Wait for settling time of 5s
[2022-01-19 20:18:28,155] [WARNING] [wlc_bench] [wl_launcher.create_subprocess]: Not received 'connected' message from media_ai_pipeline-measured_indu_hmi_high-low.    Please check if workload is connected to the MQTT broker.        Check log file for any errors.  Or your WL may not be publishing messages on MQTT.      WL Density calculations will thus be incorrect
[2022-01-19 20:18:28,155] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: Restart subscription on KPI errors channel
[2022-01-19 20:18:28,156] [INFO] [wlc_bench] [wl_launcher.create_subprocess]: Watch for KPI errors in KPI window duration of: 10s
[2022-01-19 20:18:39,179] [INFO] [wlc_bench] [wl_launcher.run]: Created: 0 of synbench_proxy-proxy-low
[2022-01-19 20:18:39,180] [INFO] [wlc_bench] [wl_launcher.run]: Created: 1 of media_ai_pipeline-measured_indu_hmi_high-low
[2022-01-19 20:18:40,173] [INFO] [wlc_bench] [broker.stop]: Disconnected from MQTT broker
[2022-01-19 20:18:40,174] [INFO] [wlc_bench] [wlc_bench.main]: Please wait for all processes to gracefully terminate and produce log files. ctrl+c not recommended
[2022-01-19 20:18:40,398] [INFO] [wlc_bench] [wl_launcher.kill]: Terminated all spawned processes
[2022-01-19 20:18:40,399] [INFO] [vm1] [ssh_interface.copy_file_to_or_from_target]: Copy From SUT to HOST
[2022-01-19 20:18:40,468] [INFO] [vm1] [ssh_interface.__download]: Download of file from remote server successful
[2022-01-19 20:18:41,571] [INFO] [wlc_bench] [wlc_bench.main]: **********************************************************************
[2022-01-19 20:18:41,572] [INFO] [wlc_bench] [wlc_bench.main]: wlc_bench execution status: SUCCESS
[2022-01-19 20:18:41,572] [INFO] [wlc_bench] [wlc_bench.main]: WLC Density (considers measured WL only): measured_indu_hmi_high = 1
[2022-01-19 20:18:41,573] [INFO] [wlc_bench] [wlc_bench.main]: **********************************************************************
[2022-01-19 20:18:41,573] [INFO] [wlc_bench] [wlc_bench.main]: Done
[2022-01-19 20:18:41,574] [INFO] [native1] [platforms_base.close]: Close in Base Platform
[2022-01-19 20:18:41,575] [INFO] [native1] [platforms_base.close]: Closing Primary Interface
[2022-01-19 20:18:41,576] [INFO] [vm1] [platforms_base.close]: Close in Base Platform
[2022-01-19 20:18:41,576] [INFO] [vm1] [platforms_base.close]: Closing Primary Interface

```
