#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x31ba17fd, "module_layout" },
	{ 0x6bc3fbc0, "__unregister_chrdev" },
	{ 0x98087065, "cdev_alloc" },
	{ 0x51b1258f, "tracepoint_probe_register" },
	{ 0xdef971, "cdev_del" },
	{ 0xb7802a4c, "pci_write_config_dword" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xfe4f520e, "__cpuhp_remove_state" },
	{ 0x89d3a0f7, "for_each_kernel_tracepoint" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x754d539c, "strlen" },
	{ 0x5021bd81, "_raw_write_lock_irqsave" },
	{ 0xef34bf3e, "hrtimer_active" },
	{ 0x263ed23b, "__x86_indirect_thunk_r12" },
	{ 0xc032559b, "cpufreq_cpu_get" },
	{ 0x46a4b118, "hrtimer_cancel" },
	{ 0xbb9a2726, "telemetry_reset_events" },
	{ 0x56470118, "__warn_printk" },
	{ 0x65d9e877, "cpufreq_register_notifier" },
	{ 0x7406e07, "device_destroy" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x102bed66, "cpu_info" },
	{ 0xa7b70aec, "param_ops_bool" },
	{ 0x804af87c, "wrmsr_safe_on_cpu" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0x999e8297, "vfree" },
	{ 0x7a2af7b4, "cpu_number" },
	{ 0xcb3801e8, "pv_ops" },
	{ 0x42635d55, "pm_suspend_global_flags" },
	{ 0xbb13595e, "smp_call_function_many" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xe2d5255a, "strcmp" },
	{ 0xeb078aee, "_raw_write_unlock_irqrestore" },
	{ 0xc5e4a5d1, "cpumask_next" },
	{ 0x6214aef2, "cpufreq_unregister_notifier" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x17de3d5, "nr_cpu_ids" },
	{ 0xa084749a, "__bitmap_or" },
	{ 0xb8e7ce2c, "__put_user_8" },
	{ 0x3c5d543a, "hrtimer_start_range_ns" },
	{ 0xfb578fc5, "memset" },
	{ 0x9e683f75, "__cpu_possible_mask" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x7ce030e3, "current_task" },
	{ 0x37befc70, "jiffies_to_msecs" },
	{ 0xc5850110, "printk" },
	{ 0x5a5a2271, "__cpu_online_mask" },
	{ 0x9ec6ca96, "ktime_get_real_ts64" },
	{ 0xde80cd09, "ioremap" },
	{ 0xd61eeee, "__bitmap_subset" },
	{ 0xe7b00dfb, "__x86_indirect_thunk_r13" },
	{ 0xa1c76e0a, "_cond_resched" },
	{ 0x9166fada, "strncpy" },
	{ 0x9cc4f70a, "register_pm_notifier" },
	{ 0x7b5f7f18, "pci_get_domain_bus_and_slot" },
	{ 0x4744e002, "device_create" },
	{ 0xce8b1878, "__x86_indirect_thunk_r14" },
	{ 0xed5d1175, "pid_task" },
	{ 0x17d7a2e3, "__cpuhp_setup_state" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x6a261b78, "irq_stat" },
	{ 0x182d44a8, "cdev_add" },
	{ 0x975e6a37, "module_put" },
	{ 0xb1342cdb, "_raw_read_lock_irqsave" },
	{ 0xb2fd5ceb, "__put_user_4" },
	{ 0x6a5cb5ee, "__get_free_pages" },
	{ 0xc959d152, "__stack_chk_fail" },
	{ 0x1000e51, "schedule" },
	{ 0x8ee9455e, "intel_punit_ipc_command" },
	{ 0xb9e7429c, "memcpy_toio" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0x2e4479e9, "pci_read_config_dword" },
	{ 0xdf2ebb87, "_raw_read_unlock_irqrestore" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x992a045c, "cpufreq_cpu_put" },
	{ 0xb19a5453, "__per_cpu_offset" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x4302d0eb, "free_pages" },
	{ 0x3eeb2322, "__wake_up" },
	{ 0x8745e7ff, "init_pid_ns" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0x39b52d19, "__bitmap_and" },
	{ 0x37a0cba, "kfree" },
	{ 0x69acdf38, "memcpy" },
	{ 0x2d0684a9, "hrtimer_init" },
	{ 0xedc03953, "iounmap" },
	{ 0x7d628444, "memcpy_fromio" },
	{ 0x7aff77a3, "__cpu_present_mask" },
	{ 0x7681946c, "unregister_pm_notifier" },
	{ 0x6b892524, "telemetry_set_sampling_period" },
	{ 0x53569707, "this_cpu_off" },
	{ 0x264e245d, "class_destroy" },
	{ 0xb352177e, "find_first_bit" },
	{ 0x4f4d9c2c, "pci_get_device" },
	{ 0x92540fbf, "finish_wait" },
	{ 0xf00771b0, "telemetry_get_eventconfig" },
	{ 0x63c4d61f, "__bitmap_weight" },
	{ 0xf80be44e, "rdmsr_safe_on_cpu" },
	{ 0x3a3a950c, "param_ops_ushort" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x2766dc72, "__class_create" },
	{ 0xa8497b41, "find_pid_ns" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x6228c21f, "smp_call_function_single" },
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
	{ 0xb9b4f223, "try_module_get" },
	{ 0x6b5f9cef, "tracepoint_probe_unregister" },
};

MODULE_INFO(depends, "intel_telemetry_core,intel_punit_ipc");


MODULE_INFO(srcversion, "B1E6EDD9E3023E30DB4C3A1");
