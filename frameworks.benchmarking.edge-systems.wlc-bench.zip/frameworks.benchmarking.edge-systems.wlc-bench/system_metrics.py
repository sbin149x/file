#!/usr/bin/env python3
#
# INTEL CONFIDENTIAL
#
# Copyright 2021 (c) Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials, and
# your use of them  is governed by the  express license under which  they were
# provided to you ("License"). Unless the License provides otherwise, you  may
# not  use,  modify,  copy, publish,  distribute,  disclose  or transmit  this
# software or the related documents without Intel"s prior written permission.
#
# This software and the related documents are provided as is, with no  express
# or implied  warranties, other  than those  that are  expressly stated in the
# License.
#
# ----------------------------------------------------------------------------
from star_fw.framework_base.logger.api_intf_logger import LoggerAPI

logging = LoggerAPI(device_tag='wlc_bench')
import os
import re
import json
import shutil
import time
from datetime import datetime

import pandas as pd
from openpyxl import load_workbook

import tool_utils
from broker import *
from star_fw.framework_base.star_decorator import StarDecorator

mqtt_based_metric_received = False


class SystemMetricsException(Exception):
    """
    Class for system metrics exceptions
    """
    pass


class SystemMetrics(object):
    """
    System Metrics class for defining, creating commands for metrics tools like
    top, gpu_top etc. Also collects and stores data in suitable log files
    """

    def __init__(self, is_capture=False, form_device_vm_mgmt_obj=None, broker=None,
                 is_local_exe_mode: bool = True):
        """
        Init system metrics object
        :param is_capture: flag True/False to indicate if system metrics to be captured or not
        """
        self._sudo_password = None
        self.cur_log_fol_path = logging.get_log_folder_path()
        self.metrics_log = os.path.join(self.cur_log_fol_path, "system_metrics.log")
        self.is_capture_metrics = is_capture
        self.tool_bank = []

        self.is_local_exe_mode = is_local_exe_mode

        self.form_dev_vm_mgmt_obj = form_device_vm_mgmt_obj
        self.tool_proc_pids = {}

        self.broker = broker
        self.system_metrics_data = []
        self.execution_mode = 'system idle'
        self.device_tag = 'wlc_bench'
        self.wl_exe_sts = {}
        self.host_lst = {}

        self.log_files = {}
        self.workload_topic_mapping = {
            's': {}
        }

    @property
    def sudo_password(self):
        """
        Property to get/set password to run sudo cmds
        :return: sudo password
        """
        return self._sudo_password

    @sudo_password.setter
    def sudo_password(self, x):
        """
        Setter
        :param x: value to be set
        :return: None
        """
        self._sudo_password = x

    @property
    def execution_mode(self):
        """
        Property to get/set mode of the execution
        :return: sudo password
        """
        return self._execution_mode

    @execution_mode.setter
    def execution_mode(self, x):
        """
        Setter
        :param x: value to be set
        :return: None
        """
        self._execution_mode = x

    @staticmethod
    def check_tool_exists(tool, loc=None, is_local_exe: bool = True):
        """
        Check if tool exists/has been installed
        :param tool: tool name in string
        :param loc: location/path to search for tool

        :return: True if yes, else False
        """
        if is_local_exe:
            if shutil.which(tool, path=loc) is None:
                logging.warning(f"Please install {tool}. Skipping {tool} metrics")
                return False

        return True

    def initialize(self):
        """
        Initialize runner with topics to subscribe to
        :return: None
        """

        def _on_sys_metric_upd(topic, payload):
            """
            KPI error callback
            :param topic: input topic string
            :param payload: received payload
            :return: disconnect from app if KPI err msg received, else continue
            """
            global mqtt_based_metric_received

            mqtt_based_metric_received = True
            try:
                payload = json.loads(payload)
                logging.debug(f"[Received] on : {topic} message: {payload}")

                # Topic Template:
                # host_name/tool_name/tool_type/kpi/metric/<metrics_id>/value,
                # Eg: native.vm1/top/cpu/kpi/metric/cup_utilization/value
                #
                # +===========+===========+===========+
                # +.Host.Name.+.Tool.Name.+.Tool.Type.+
                # +===========+===========+===========+
                val = topic.split("/")

                # synbench_proxy/p1/kpi/system_metric/cpu/value
                metric_type = val[-2]
                metric_value = payload

                data_mapping = self.workload_topic_mapping['s']
                metrics_info = data_mapping.get(val[-5])

                if metrics_info:
                    copped_metrics_info = metrics_info.split("/")

                    host_name = copped_metrics_info[0]
                    tool_name = copped_metrics_info[1]
                    tool_type = copped_metrics_info[2]

                    self.system_metrics_data.append([host_name, self.execution_mode, tool_name, tool_type,
                                                     self.wl_exe_sts.get(host_name, {}).get('proxy', 0),
                                                     self.wl_exe_sts.get(host_name, {}).get('measured', 0),
                                                     metric_type,
                                                     metric_value])
                    # logging.debug(f'Added System Metric Data {self.system_metrics_data}')
            except IndexError:
                logging.error(f"mqtt topic is not aligned to the expectation received topic: {topic} "
                              f"expected: toolname/APPID")
            except json.decoder.JSONDecodeError as _:
                logging.error(f"Could not parse raw data: {payload}")

        try:
            logging.info(f"Subscribe to initial topics with callbacks for System Metrics")
            # 'tool_name/1234/kpi/system_metric/sys_cpu_utilization/value'
            topic_appender = '+/+'

            topic_metric = f"{topic_appender}/kpi/system_metric/+/+"
            self.broker.subscribe(topic_metric, _on_sys_metric_upd)
        except Exception as e:
            raise BrokerException(e)

    def collect_store(self, pids=None, wl_type=None):
        """
        Function to collect and write all system metric measurements in log files
        :param pids: dict of proxy, measured wls -
                     dict(proxy-high: [list of pids], measured-high: [list of pids]
        :param wl_type: type of workload, proxy or measured
        :return: None
        """

        if mqtt_based_metric_received:
            logging.debug('MQTT Based System metrics data receive so skippingg legacy method !!')
            return False

        total = total_proxy = total_measured = 0
        proxy_str = measured_str = ""

        logging.debug(pids)

        # find total # of proxy wl and measured wl instantiated till now
        # find what all types of proxy, measured wl have been started
        if pids is not None:
            for k, v in pids.items():
                if "proxy" in k:
                    total_proxy += len(v)
                    proxy_str += f"{k}, "
                if "measured" in k:
                    total_measured += len(v)
                    measured_str += f"{k}, "

                total += len(v)

        if wl_type is None:
            ret_val = ["None", "None", "System Idle"]
            log = "system idle"

        elif wl_type == "proxy":
            ret_val = [f"{total_proxy} * ({proxy_str})", "None", total_proxy]
            log = f"{total_proxy} proxy instance ({proxy_str})"

        else:
            ret_val = [f"{total_proxy} * ({proxy_str})", f"{total_measured} * ({measured_str})", total]
            log = f"{total} instances = {total_proxy} * ({proxy_str}) + {total_measured} * ({measured_str})"

        df_cols = ["Proxy WL", "Measure WL", "Total # WL"]

        # write data in system_metrics log file
        metrics_file = open(self.metrics_log, "a+")
        metrics_file.write(f"{log}:\n")

        if not self.is_local_exe_mode:
            dst = logging.get_log_folder_path()
            if not os.path.exists(dst):
                os.makedirs(dst)

            for host, log_file_list in self.log_files.items():
                host_name_lst = host.split('.')

                host_obj = self.form_dev_vm_mgmt_obj.virt_mgmt_obj_dict.get(host)

                if not host_obj:
                    host_obj = self.form_dev_vm_mgmt_obj.virt_mgmt_obj_dict.get(host_name_lst[0])
                    if host_obj:
                        if len(host_name_lst) > 1:
                            for obj in host_name_lst[1:]:
                                host_obj = host_obj.vm_obj_dict.get(obj)
                        else:
                            if hasattr(host_obj, 'sut_obj'):
                                host_obj = host_obj.sut_obj
                else:
                    if hasattr(host_obj, 'sut_obj'):
                        host_obj = host_obj.sut_obj

                if not host_obj:
                    raise Exception(f'Invalid host name is defined for the wl launch in yaml config {host}')

                for log in log_file_list:
                    dst = os.path.join(dst, os.path.basename(log))
                    copy_sts = host_obj.copy_file_to_or_from_target(src_path=log, dst_path=dst,
                                                                    to_target=False)
                    if not copy_sts.get('status', False):
                        logging.error(f'Failed to copy the logs from {host}')

        for tool in self.tool_bank:

            tool_name = tool["name"]
            log_file_path = os.path.join(self.cur_log_fol_path, f'/log_stdout_{tool_name}.log')

            # add the CPU usage
            if "cpu" in tool["type"]:

                top_data = tool_utils.get_cpu_top_data(cpu_log_file=log_file_path)

                cpu_data = -1

                # if dictionary is returned extract the stored data
                if top_data is not None:
                    cpu_data = top_data["CPU Usage"]
                    ram_usg = top_data["RAM Usage"]
                    total_ram = top_data["Total RAM"]
                    swap_usg = top_data["Swap Usage"]
                    total_swap = top_data["Total Swap"]

                # if top data > 0, include in excel - if any errors from top, skip
                if cpu_data >= 0:
                    ret_val.append(cpu_data)
                    metrics_file.write(f"\tCPU usage {ret_val[3]}\n")

                    df_cols.append("CPU Usage")

                # Add the total RAM and SWAP usage
                if ram_usg and total_ram and swap_usg and total_swap:
                    ret_val.append(str(ram_usg) + " / " + str(total_ram))
                    ret_val.append(str(swap_usg) + " / " + str(total_swap))
                    metrics_file.write(f"\tRAM usage: {ram_usg}\n")
                    metrics_file.write(f"\tTotal RAM: {total_ram}\n")
                    metrics_file.write(f"\tSwap usage: {swap_usg}\n")
                    metrics_file.write(f"\tTotal Swap: {total_swap}\n")

                    df_cols.append("RAM Usage / Total RAM")
                    df_cols.append("Swap Usage / Total Swap")

            # add the GPU usage
            if "gpu" in tool["type"]:

                gpu_data = tool_utils.get_gpu_top_data(gpu_log_file=log_file_path)

                # if gpu data list got populated, include in excel - if any errors, skip
                if gpu_data:
                    metrics_file.write(f"\tGPU freq {gpu_data[0]} Mhz\n")
                    metrics_file.write(f"\tGPU render {gpu_data[1]}\n")

                    ret_val.append(f"{gpu_data[0]} Mhz")
                    ret_val.append(gpu_data[1])

                    df_cols.append("GPU Freq")
                    df_cols.append("GPU Render")

            # add the power data
            if "power" in tool["type"]:

                # collect socwatch per workload
                self.start(tool)
                power_data = tool_utils.get_cpu_socwatch_power(total)

                if power_data:
                    ret_val = ret_val + [f"{power_data[0]} mW", f"{power_data[1]} mJ", f"{power_data[2]} MB/s"]

                    metrics_file.write(f"\tSOC Avg Power {power_data[0]} mW\n")
                    metrics_file.write(f"\tSOC Total Power {power_data[1]} mJ\n")
                    metrics_file.write(f"\tSOC Total Memory BW {power_data[2]} MB/s\n")

                    df_cols = df_cols + ["SOC Avg Power", "SOC Total Power", "SOC Total Memory BW"]

            # add pdu data if defined:
            if "pdu" in tool["type"]:
                pdu_data = tool_utils.get_pdu_target_power(tool)

                if pdu_data:
                    ret_val.append(f"{pdu_data} A")
                    df_cols.append("PDU Power")
                    metrics_file.write(f"\tPDU Power {pdu_data} A")

        metrics_file.write("\n")
        metrics_file.close()

        self.save_to_xls(df_cols, ret_val)
        return True

    def save_to_xls(self, df_cols, ret_val):
        """
        Saves values to xls
        :param df_cols: pandas dataframe
        :param ret_val: list of values
        :return: None
        """
        # open mode for excel file (write / append)
        xls_file = f"{self.metrics_log}.xlsx"

        try:
            df = pd.DataFrame([ret_val], columns=df_cols)

            if os.path.exists(xls_file) and os.path.isfile(xls_file):

                with pd.ExcelWriter(xls_file, engine="openpyxl", mode="a") as writer:
                    writer.book = load_workbook(xls_file)
                    writer.sheets = dict((ws.title, ws) for ws in writer.book.worksheets)
                    reader = pd.read_excel(xls_file, engine="openpyxl")
                    df.to_excel(writer, sheet_name="System Metrics", index=False,
                                header=False, startrow=len(reader) + 1)

            else:

                with pd.ExcelWriter(xls_file) as writer:
                    df.to_excel(writer, sheet_name="System Metrics", index=False)
                    worksheet = writer.sheets["System Metrics"]
                    worksheet.set_column(0, 1, 40, writer.book.add_format(
                        {"align": "center", "valign": "vcenter", "text_wrap": True}))
                    worksheet.set_column(2, 11, 26, writer.book.add_format(
                        {"align": "center", "valign": "vcenter", "text_wrap": True}))

        except Exception as e:
            self.kill()
            logging.error(f"Could not populate excel file: {xls_file}")
            raise SystemMetricsException(e)

    def start(self, tool):
        """
        Start metrics tools as subprocesses in the background. Stores pids in dictionary
        :param tool tool obj created when wlc_bench gets launched holding all attributes of that tool
        :return: None
        """
        start_cmd = tool['start_cmd']
        tool_name = tool["name"]
        host = tool['host']
        tool_type = tool["type"]

        StarDecorator.double_blocked_print(f"Starting System Metric Tool: {tool_name}")

        host_name_lst = host.split('.')
        host_obj = self.form_dev_vm_mgmt_obj.virt_mgmt_obj_dict.get(host)

        if not host_obj:
            host_obj = self.form_dev_vm_mgmt_obj.virt_mgmt_obj_dict.get(host_name_lst[0])
            if host_obj:
                if len(host_name_lst) > 1:
                    for obj in host_name_lst[1:]:
                        host_obj = host_obj.vm_obj_dict.get(obj)
                else:
                    if hasattr(host_obj, 'sut_obj'):
                        host_obj = host_obj.sut_obj
        else:
            if hasattr(host_obj, 'sut_obj'):
                host_obj = host_obj.sut_obj

        if not host_obj:
            raise Exception(f'Invalid host name is defined for the wl launch in yaml config {host}')

        self.host_lst[host] = host_obj
        uname = host_obj.username
        remote_logs_path = f'/home/{uname}/sys_metric_logs/'

        folder_path = self.cur_log_fol_path if self.is_local_exe_mode else remote_logs_path

        host_obj.execute(f'mkdir {folder_path}')
        file_name = f"{folder_path}/log_stdout_{tool_name}.log"

        logging.info(f'Tool Log Path: {file_name}')

        if not self.log_files.get(host, None):
            self.log_files[host] = []

        self.log_files[host].append(file_name)
        trigger_cmd = start_cmd
        if start_cmd.find('-mt') >= 0:
            trigger_cmd = self.__update_topic_in_cmd_with_req_params(host, tool_name, tool_type, start_cmd)

        pid_match_str = self.__get_pat_match_str(trigger_cmd)
        if host_obj.os_name == 'windows':
            pid_match_str = self.__add_escape_chars(pid_match_str)

            # WAR
            trigger_cmd = f'cmd.exe /c {trigger_cmd}'

        trigger_cmd = f'{trigger_cmd} > {file_name}'

        if tool.get("is_sudo", None):
            trigger_cmd = f'echo {self.sudo_password} | sudo -S {trigger_cmd}'

        wl_exe_sts = host_obj.send_background(command=trigger_cmd)

        if not wl_exe_sts.get('status', False):
            logging.error(f'Failed to run Tool: {tool_name}')
            return

        # session_id = wl_exe_sts.get('session_id', None)

        logging.debug(f'Process name to get the PID: {pid_match_str}')
        pid_sts = host_obj.get_pid_of_process(pid_match_str)
        if not pid_sts.get('status', False):
            logging.error(f'Failed to get PID of {tool_name}')
            return

        pid_lst = pid_sts.get('pid')
        if not self.tool_proc_pids.get(tool_name, None):
            self.tool_proc_pids[f"{tool_name}"] = {}

        if not self.tool_proc_pids[f"{tool_name}"].get(host, None):
            self.tool_proc_pids[f"{tool_name}"][host] = {}
            self.tool_proc_pids[f"{tool_name}"][host]['host_obj'] = host_obj
            self.tool_proc_pids[f"{tool_name}"][host]['pid'] = []

        self.tool_proc_pids[f"{tool_name}"][host]['pid'].append(pid_lst)

        # wait 2 seconds for metrics tools to start and log values correctly
        logging.debug("Sleeping for 5 seconds to ensure tool has started")
        time.sleep(5)

    def kill(self):
        """
        Terminates metrics tools
        :return: None
        """
        for tool_name, host_data in self.tool_proc_pids.items():
            for host_name, data_dict  in host_data.items():
                with_prv = not host_name.find('.') > 0
                host_obj = data_dict.get('host_obj')
                pid_list = tuple(data_dict.get('pid'))
                logging.debug(f'Killing System Metric Tool Process - {pid_list}')
                try:
                    sts = host_obj.kill_process_with_pid(pid_list, with_privilege=with_prv)

                    if not sts.get('status', False):
                        logging.error(f'Failed to kill the System Metric Tool {tool_name}, pid {pid}')
                except:
                    pass

    def __update_topic_in_cmd_with_req_params(self, host, tool_name, tool_type, cmd):
        topic = f'{host}/{tool_name}/{tool_type}'
        logging.debug(f'Topic: {topic}')

        mapping = self.workload_topic_mapping['s']
        mat_pat = r'(-mt[:\s]+)([a-zA-Z0-9_]+/\d+)'

        # Sample
        # Input - /home/kpi/kpi-test-suite/tools/system_cpu.sh -mb 10.34.40.213 -mt kpi/123
        # Output - [('-mt ', 'kpi/123')]
        matched_str = re.findall(mat_pat, cmd)
        if not matched_str:
            raise Exception('Failed to get the user topic from the start command !!')

        matched_str = matched_str[0]

        # Assuming 1st argument to the WL script is Topic always
        # Eg: /home/kpi/kpi-test-suite/gst/media_ai_pipeline.sh -mt apps/123 10.34.40.213 false CPU
        user_topic = matched_str[1]
        logging.debug(f'User Topic: {user_topic}')

        topic_count = f's{len(mapping)+1}'
        new_top = f'{tool_name}/s{len(mapping)+1}'
        mapping[topic_count] = topic

        new_top = f'{matched_str[0]}{new_top}'

        trigger_cmd = re.sub(mat_pat, new_top, cmd)
        logging.debug(f'Updated Topic: Mapping {new_top}: {topic}')
        logging.debug(f'Triggering Command: {trigger_cmd}')

        return trigger_cmd

    def __add_escape_chars(self, str_data: str) -> str:
        """
        Method to add the escape character for all special characters like |, +, $, { etc

        :param str_data: Required - Data to which the escape character to be added

        :return: String with escape character added
        """
        str_data = str_data.replace('\\', '\\\\')
        char_list = [r"\|", r"\+", r"\{", r"\}", r"\$", r"\^", r"\@", r"\'"]

        for char in char_list:
            str_data = re.sub(char, f'\\{char}', str_data, flags=re.DOTALL)

        return str_data

    def __get_pat_match_str(self, command: str) -> str:
        """
        Method to get the pattern matcher string from the given command and truncate the string if length is > 150

        Example:
            Input - /home/kpi/kpi-test/gst/media_ai_pipeline.sh kpi/metric/+/+ 10.34.40.213 420p_1920x1080_2mbps_8b.h265
            Output - /home/kpi/kpi-test/gst/media_ai_pipeline.sh.*kpi/metric/+/+.*10.34.40.213.*420p_1920x1080_2mbps_8b.h265

        :param command: Command to get the pattern mather and truncate

        :return: Pattern matcher String
        """
        match_cmd = command
        if len(command) > 150:
            near_space = command.find(' ', 145)
            match_cmd = command[:near_space] + '.*'

        return f'.*{".*".join(match_cmd.split())}'

    def write_sys_metric_xlsx(self):
        """
        Method to generate the xlsx data collected via MQTT message
        """
        if not mqtt_based_metric_received:
            logging.debug('No MQTT Based System metrics data receive so skipping Data sheet creation!!')
            return

        # todo - Configurable Name
        data_sheet_name = f'wlc_bench_system_metrics.csv'
        metric_data_sheet_path = os.path.join(logging.get_log_folder_path(), data_sheet_name)

        row_data = {}
        for idx, row in enumerate(self.system_metrics_data):
            row_data[f'row_{idx}'] = row

        headers_list = ['Host Name', 'Execution Mode', 'Tool Name', 'Tool Type',
                        'Proxy WL Count', 'Measure WL Count', 'System Metric Name', 'System Metric Value']

        sys_metrics_data_frame = pd.DataFrame.from_dict(row_data, orient='index', columns=headers_list)

        # write each DataFrame to a specific sheet
        sys_metrics_data_frame.to_csv(metric_data_sheet_path, index=False)
        logging.info(f'Measurements Data Sheet created successfully: {metric_data_sheet_path} !')
