# Overview

This is the regression suite for wlc_bench. Every commit needs to make sure that it does not break any functionality of the framework.

# Pre-Requisites

0.  An Ansible playbook will be available that will install all pre-requisites (currently the setup needs to be done manually)

1. Install all pre-requisites and install steps from the readme file in wlc_bench 

2. Clone Synbench and follow the setup instructions:
https://github.com/intel-innersource/drivers.gpu.virtualization.synbench/tree/hmi_proxy

3. Clone NVR project and follow the setup instructions:
https://github.com/intel-sandbox/frameworks.benchmarking.edge-systems.nvr-bench/tree/main

4. Clone ADD project and follow the setup instructions:
https://github.com/intel-sandbox/containers.docker.benchmarking.add-analytics/tree/ADD_weld_porosity_container_ADLS

5. Clone Time series and follow the setup instructions:
https://github.com/intel-sandbox/time-series-proxy-workload/tree/main

6. OS tested: Ubuntu 20.04 and 21.04, tested using Python3.8

# Configuration file
Currently we have configuration files for NVR and Time series which follow the default instalation path (from Ansible playbook)

# Execution
./regression_tests.sh