"""
Copyright: 2019-2021 Intel Corporation
Author: Giridharan Rajendran <giridharan.rajendran@intel.com> [23 Nov 2021]

Class contains the functionality like Parsing the yaml file, To initialize device objects based on the information
    in yaml file. Yaml file contains the information related to device and Virtual Machine likes Host, User_name,
    Password, where the workloads to be run.

Sample Yaml File - frameworks.automation.star.kpi-usecases/wlc_config.yaml
"""

import platform
import socket
import getpass

from star_fw.framework_base.logger.api_intf_logger import LoggerAPI
from star_fw.framework_base.base_device.api_intf_base_platforms import BasePlatformAPI
from iotg_virtualization.api_intf_virtmgmt import VirtMgmtAPI
from star_fw.framework_base.star_decorator import StarDecorator

logging = LoggerAPI(device_tag='wlc_bench')


class FormDevVirtMgmtBase:
    """
    Class contains the functionality like Parsing the yaml file, To initialize device objects based on the
    information in yaml file.
    """

    def __init__(self):
        self.device_tag = 'wlc_bench'
        self.is_local_exe_mode = False
        self.native_dev_dict = {}
        self.virt_mgmt_obj_dict = {}
        self.zc_build = ''
        self.is_fresh_vm_launch_req = True
        self.is_vm_obj_req = False

    def create_dev_obj(self, dev_name, os: str, intf_type: str = 'ssh', host: str = '', user: str = None,
                       password: str = None, port: str = '22', is_connection_req: bool = True, via_ip: str = None,
                       via_username: str = None, via_password: str = None, is_vm: bool = False, **_: any) -> any:
        """
        API to get the device object along with test interface based on input args.

        :param dev_name: Required - Name of the corresponding device Eg: native1, vm1, vm2
        :param os: Required - OS Name of the corresponding device
        :param intf_type: Required - Primary Test interface type Eg: 'ssh/local'
        :param host: Required - ip address of device, "xx.xx.xx.xx/DYNAMIC" required for all ip based  transport
            interface like ssh
        :param user: Optional - Username used to connect to the specific interface, required for all  ip based
            transport interface like ssh
        :param password: Required only for SSH interface: Password
        :param port: Optional - Device port, only for serial interface the port can be dynamic -
            if the platform have the serial port ID Eg: ssh- "22"
        :param is_connection_req: Optional - Boolean to set the connection requires or not.
        :param via_ip: Required only in case of ssh over remote IP - IP address of the remote host machine
        :param is_vm: Optional - Flag to mention where the device is VM or SUT
        :param via_username: Required in case of ssh over remote IP - user name of the remote host machine
        :param via_password: Required in case of ssh over remote IP - password of remote host machine

        :return: Device object
        """
        args = locals()
        args.pop('self')
        logging.info(f'Creating device object for - {args}')

        dev_obj = BasePlatformAPI(os_name=os, username=user, password=password, device_tag=dev_name)
        setattr(dev_obj, 'dev_info_dict', args)

        native_host_name = socket.gethostname()
        native_ip_addr = socket.gethostbyname(native_host_name)
        logging.debug(f'Native Host name: {native_host_name} and IP Address: {native_ip_addr}')

        if os == 'android':
            logging.debug('Changing the interface to ADB for Android VM...')
            intf_type = 'adb'

            if self.native_dev_dict:
                via_ip = self.native_dev_dict.get('host', None)
                via_username = self.native_dev_dict.get('user', None)
                via_password = self.native_dev_dict.get('password', None)

        if not is_vm and (host == 'localhost' or host == '127.0.0.1' or host == '127.0.1.1' or native_ip_addr == host or
                          native_host_name == host):
            logging.info(f'Local Execution detected, WLC Bench is running on Native Setup...')
            intf_type = 'local'
            self.is_local_exe_mode = True

        enable_pty = True
        if not is_vm:
            dev_dict = locals()
            dev_dict.pop('self')
            dev_dict.pop('_')

            self.native_dev_dict = dev_dict.copy()
            self.native_obj = dev_obj
            setattr(dev_obj, 'is_native', True)
            enable_pty = False

        sts_dict = dev_obj.add_test_interface(intf_type=intf_type, ipaddr=host, port=port, via_ip=via_ip,
                                              enable_pty=enable_pty, via_username=via_username,
                                              via_password=via_password)
        if not sts_dict.get('status', False):
            logging.error('adding test interface failed')

        if is_connection_req:
                logging.debug('connecting test interface...')
                sts_dict = dev_obj.connect_test_interface(is_prompt_check_required=False)
                if not sts_dict.get('status', False):
                    logging.error('connect_test_interface failed')

        return dev_obj

    def create_multiple_dev_objects(self, parsed_yml_data: dict) -> dict:
        """
        Method to initialise all device object based on the configuration in YAML file

        :param parsed_yml_data:  Dict of the device data

        :return: dict of the device object created
        """
        expanded_data = {}

        StarDecorator.double_blocked_print('Creating require device Objects based on YAML configuration')
        self._get_expanded_dev_list(expanded_data, parsed_yml_data)

        for dev_name, dev_dict in expanded_data.items():
            via_ip = dev_dict.get('host')
            dev_port = dev_dict.get('port', '22')
            global_launch_flag = dev_dict.get('launch_vm', True)
            platform = dev_dict.get('platform', '').lower()
            virtual_tool_type = dev_dict.get('vm_launch_tool', 'qemu').lower()
            libvirtxml = dev_dict.get('libvirtxml', '')

            dev_tag = dev_name
            linked_to = dev_dict.pop('linked_to', None)
            if linked_to:
                dev_tag = f"{linked_to}.{dev_name}"

            if self.is_vm_obj_req and not dev_dict.get('is_vm', False):
                dev_obj = self.create_dev_obj(dev_tag, **dev_dict)
                logging.info(f'Initializing virtualization tool Object for SUT: {dev_name}')
                virt_mgmt_obj = VirtMgmtAPI(sut_obj=dev_obj, sut_ipaddr=via_ip, device_tag=dev_name,
                                            platform=platform, is_fresh_launch=self.is_fresh_vm_launch_req)

                self.virt_mgmt_obj_dict[dev_name] = virt_mgmt_obj

            if dev_dict.get('is_vm', False) and dev_dict.get('vm_launch_flag', False):
                StarDecorator.double_blocked_print(f'Launching VM {dev_name} in {linked_to}...')
                image_path = dev_dict.get('image_path')
                cpu = dev_dict.get('cpu')
                ram = dev_dict.get('ram')
                username = dev_dict.get('user')
                password = dev_dict.get('password')
                vm_type = dev_dict.get('bios_type', 'bios').lower()
                gpu_pass_through = dev_dict.get('gpu_passthrough', 0)
                dev_os_name = dev_dict.get('os').lower()
                zc_build = dev_dict.get('zc_build')
                force_launch = dev_dict.get('force_launch', True)

                virt_mgmt_obj = self.virt_mgmt_obj_dict.get(linked_to)

                if not virt_mgmt_obj:
                    raise Exception('No Virt Manager is initialized')

                sts_dict = virt_mgmt_obj.launch_vm(virtual_tool_type=virtual_tool_type, vm_name=dev_name,
                                                   username=username, password=password, zc_build=zc_build,
                                                   os_name=dev_os_name, os_type=vm_type, os_image=image_path, ram=ram,
                                                   cpu=cpu, port=dev_port, gpu_pass=gpu_pass_through,
                                                   platform=platform, is_force_launch=force_launch,
                                                   vm_launch_xml_path=libvirtxml)

                if not sts_dict.get('status', False):
                    raise Exception(f'Failed to launch required VM {sts_dict.get("msg", "")}')

                if not dev_dict.get('host', None):
                    sut_ip = sts_dict.get('ipaddr', None)
                    dev_dict['host'] = sut_ip
            else:
                if dev_dict.get('is_vm', False):
                    logging.info(f'Launching VM {dev_name} Skipped ')

                if linked_to:
                    dev_name = f"{linked_to}.{dev_name}"

                if not self.virt_mgmt_obj_dict.get(dev_name, None):
                    dev_obj = self.create_dev_obj(dev_tag, **dev_dict)
                    self.virt_mgmt_obj_dict[dev_name] = dev_obj

        return self.virt_mgmt_obj_dict

    def _get_expanded_dev_list(self, expanded_device_dict: dict, yml_device_data: dict) -> None:
        """
        Method to expand the given device dict

        :param expanded_device_dict: Expanded device dict
        :param yml_device_data: original data from the yaml file

        :return: None
        """
        rem_lst = []

        for dev_name, dev_dict in yml_device_data.items():
            for key, info in dev_dict.items():
                if isinstance(info, dict):
                    for k, val in info.items():
                        if val is None or (isinstance(val, str) and val.lower() == 'null'):
                            rem_lst.append(f'{dev_name}.{key}.{k}')
                else:
                    if info is None or (isinstance(info, str) and info.lower() == 'null'):
                        rem_lst.append(f'{dev_name}.{key}')

        # Block to remove the Key with Empty Value like None/Null
        for itm in rem_lst:
            keys_list = itm.split('.')

            final_dict = yml_device_data
            for key in keys_list[:-1]:
                final_dict = final_dict.get(key)

            final_dict.pop(keys_list[-1])

        for dev_name, dev_dict in yml_device_data.items():
            expanded_device_dict[dev_name] = {}
            temp_dev = {}
            glob_vm_launch_flag = dev_dict.get('launch_vm', True)
            vm_launch_tool = dev_dict.get('vm_launch_tool', 'qemu')

            for key, info in dev_dict.items():
                if isinstance(info, dict):

                    vm_launch_flag = info.get('launch_vm', glob_vm_launch_flag)
                    vm_launch_tool = info.get('vm_launch_tool', vm_launch_tool)

                    host = info.get('host', None)
                    if not vm_launch_flag and vm_launch_tool == 'libvirt' and not host:
                        raise Exception(f'Provide Host name or the IP of the VM launched Manually to proceed !!')

                    info['linked_to'] = dev_name
                    info['is_vm'] = True

                    info['vm_launch_flag'] = vm_launch_flag
                    info['vm_launch_tool'] = vm_launch_tool

                    # if only native is defined without any info
                    host = temp_dev.get('host', None)
                    if not host or host == 'null':
                        temp_dev = {
                            'host': platform.uname().node,
                            'os': platform.system().lower(),
                            'user': getpass.getuser()
                        }

                    if self.is_fresh_vm_launch_req:
                        self.is_fresh_vm_launch_req = vm_launch_flag

                    if not self.is_vm_obj_req:
                        self.is_vm_obj_req = vm_launch_flag

                    if not info.get('host', None):
                        info['host'] = temp_dev.get('host', '')
                        info['dev_username'] = temp_dev.get('user', '')
                        info['dev_password'] = temp_dev.get('password', '')

                    self._get_expanded_dev_list(expanded_device_dict, {key: info})
                else:
                    temp_dev[key] = info
            expanded_device_dict[dev_name] = temp_dev

        logging.debug(f'Expanded Device List: {expanded_device_dict}')
