#!/usr/bin/env python3
#
# INTEL CONFIDENTIAL
#
# Copyright 2021 - 2022 (c) Intel Corporation.
#
# This software and the related documents are Intel copyrighted materials, and
# your use of them  is governed by the  express license under which  they were
# provided to you ("License"). Unless the License provides otherwise, you  may
# not  use,  modify,  copy, publish,  distribute,  disclose  or transmit  this
# software or the related documents without Intel"s prior written permission.
#
# This software and the related documents are provided as is, with no  express
# or implied  warranties, other  than those  that are  expressly stated in the
# License.
#
# ----------------------------------------------------------------------------

import os
import sys
import time
import platform
import getpass
import glob
import re
from datetime import datetime

from star_fw.framework_base.logger.api_intf_logger import LoggerAPI

log_path = os.path.join(os.getcwd(), 'logs', 'wlc_bench_logs')
logging = LoggerAPI(device_tag='wlc_bench', log_fol_path=log_path, log_file_name='wlc_bench_logs')

from broker import Broker
from system_metrics import SystemMetrics
from wl_launcher import WlLauncher
from yml_parser import YAMLParser
from form_dev_vm_mgmt.form_dev_vm_mgmt import FormDevVirtMgmtBase
from star_fw.framework_base.star_decorator import StarDecorator
from form_dev_vm_mgmt.vm_yaml_validate import validate_vm_yaml


def main():
    """
    Main function
    1. parse cmd line
    2. call yaml parser
    3. extract values
    4. start broker
    5. initiate system_metrics, runner
    6. cleanup
    7. report density/max fps number
    :return: wlc density/max fps value
    """
    # Check arguments
    dev_obj_dict = {}
    broker = None
    runner = None
    system_metrics = None
    form_dev_vm_mgmt_obj = None
    default_mode = False
    wrk_dict = {}
    measured = {}
    first_measured = {}
    is_local_exe_mode = True

    # default mode, none other currently defined
    wlc_bench_mode = "breakpoint_serial"

    cur_log_fol_path = logging.get_log_folder_path()
    logging.info(f'wlc logs path for current execution: {cur_log_fol_path}')

    try:
        if len(sys.argv) != 2:
            sys.exit("Usage: ./wlc_bench.py <config.yaml>")

        # no longer need to specify breakpoint_serial, only takes 1 arg - yml file
        yml_file = sys.argv[1]

        # parse YML file
        StarDecorator.double_blocked_print(f'Parsing YAML Config File: {yml_file}', logger=logging)
        parser = YAMLParser(yml_file)
        parsed_file = parser.parse()

        # get proxy, measured wl params
        settling_time, log_level = get_yml_values(wlc_bench_mode, parsed_file, parser)
        log_level = 'INFO' if not log_level else 'DEBUG'

        logging.set_log_level(log_level)
        mode = parser.get(wlc_bench_mode, parsed_file)

        # get list of env variables
        env_var_list = parser.get("env_vars", mode)
        for var in env_var_list:
            temp = var.split("=")
            logging.info(f"Setting env variable: {var}")
            os.environ[temp[0]] = temp[1]

        form_dev_vm_mgmt_obj = FormDevVirtMgmtBase()

        # Setup Devices based on the YML Configurations
        if 'system_configs' in parsed_file:
            system_configs_data = parser.get('system_configs', parsed_file)
        else:
            logging.debug('No System configs are configured, so populating the default...')
            system_configs_data = {
                'native': {
                    'host': platform.uname().node,
                    'os': platform.system().lower(),
                    'user': getpass.getuser()
                }
            }

        for key, _ in mode.items():
            if 'proxy_wl' in key or 'measured_wl' in key:
                default_mode = True
                break

        if not default_mode:
            validate_vm_yaml(parsed_file, wlc_bench_mode)

        dev_obj_dict = form_dev_vm_mgmt_obj.create_multiple_dev_objects(parsed_yml_data=system_configs_data)
        is_local_exe_mode = form_dev_vm_mgmt_obj.is_local_exe_mode

        logging.info(f'Parsing workloads from YAML Configuration. Default mode:{default_mode}')

        # Default Mode is to support old Yaml configuration
        if default_mode:
            # get all proxy, measured wl details
            proxy = parser.get("proxy_wl", mode)
            proxy["type"] = "proxy"
            measured = parser.get("measured_wl", mode)

            wrk_dict['native'] = setup_workloads(proxy, measured)
        else:
            for key, _ in mode.items():

                if key in ['env_vars', 'loglevel', 'settling_time']:
                    continue

                host_wlks = parser.get(key, mode)

                # get all proxy, measured wl details
                proxy = host_wlks.get("proxy_wl", None)
                if proxy is None:
                    logging.info('No proxy WL found for this host')
                else:
                    proxy["type"] = "proxy"
                measured = host_wlks.get("measured_wl", None)

                if not first_measured and measured:
                    first_measured = measured.copy()

                wrk_dict[key] = setup_workloads(proxy, measured)

        # get mqtt values
        mqtt_host, mqtt_port = get_mqtt_yml_values("mqtt", parsed_file, parser)

        logging.info(f'Setting Mqtt Broker Host: {mqtt_host} and Port: {mqtt_port}')
        # setup broker
        broker = Broker(mqtt_host, mqtt_port)
        broker.start()

        runner = system_metrics = None

        logging.info(f'Parsing system metrics tools from YAML Configuration')
        metrics = parser.get("system_metrics", parsed_file)
        is_metrics_capture = parser.get("measure", metrics)

        system_metrics = SystemMetrics(is_metrics_capture, form_device_vm_mgmt_obj=form_dev_vm_mgmt_obj, broker=broker,
                                       is_local_exe_mode=is_local_exe_mode)
        system_metrics.initialize()

        # metrics=True, start tools
        if is_metrics_capture:
            # get sudo password, avoid asking each time in for loop
            if "root_pass" in metrics:
                logging.info("Using sudo password from the config file")
                system_metrics.sudo_password = parser.get("root_pass", metrics)
                # check that password was not taken with last <<,>> character
                if str(system_metrics.sudo_password).endswith(","):
                    system_metrics.sudo_password = system_metrics.sudo_password[:-1]
            else:
                logging.info("Please enter sudo password which will be used for running metrics tools "
                             "requiring sudo access")
                system_metrics.sudo_password = getpass.getpass()

            tools = parser.get("tools", metrics)

            if default_mode:
                tools_lst = tools
                tools = {'native': tools_lst}

            for host, tools_lst in tools.items():
                for tool in tools_lst:
                    name = tool["name"]
                    loc = tool["loc"] if "loc" in tool else None
                    tool['host'] = host

                    # nothing to start for pdu, skip start step only for pdu
                    if "pdu" in name:
                        if tool["use_pdu"]:
                            system_metrics.tool_bank.append(tool)
                        else:
                            logging.warning(f"use_pdu False. Skipping pdu metrics")
                        # no command to start for pdu, skip iteration
                        continue

                    # start all tools
                    if system_metrics.check_tool_exists(name, loc=loc, is_local_exe=is_local_exe_mode):
                        system_metrics.tool_bank.append(tool)
                        if "socwatch" in name:
                            continue
                        system_metrics.start(tool)

            # first pass, no workloads, system idle measurements
            system_metrics.collect_store()

        # start workload launcher
        runner = WlLauncher(wrk_dict, settling_time, system_metrics, broker, form_dev_vm_mgmt_obj)
        runner.run()
    except Exception as exp:
        logging.exception(f'Exception occurred in the execution: {exp}')

    finally:
        # To Catch the exceptions in block and kill the launched VM's
        try:
            # all cleanup
            if broker:
                broker.stop()

            logging.info("Please wait for all processes to gracefully terminate and produce log files."
                         " ctrl+c not recommended")
            if system_metrics:
                system_metrics.kill()

            if runner:
                runner.kill()

                for host, logs_list in runner.log_files.items():
                    dev_name = host.split('.')[-1]
                    dst = f'{logging.get_log_folder_path()}/{dev_name}_logs/'

                    if not os.path.exists(dst):
                        os.makedirs(dst)

                    host_obj = form_dev_vm_mgmt_obj.virt_mgmt_obj_dict.get(host)

                    if not host_obj:
                        host_name_lst = host.split('.')
                        host_obj = form_dev_vm_mgmt_obj.virt_mgmt_obj_dict[host_name_lst[0]]
                        if len(host_name_lst) > 1:
                            for obj in host_name_lst[1:]:
                                if hasattr(host_obj, 'vm_obj_dict'):
                                    host_obj = host_obj.vm_obj_dict.get(obj)
                                else:
                                    host_obj = form_dev_vm_mgmt_obj.virt_mgmt_obj_dict[host]
                        else:
                            if hasattr(host_obj, 'sut_obj'):
                                host_obj = host_obj.sut_obj
                    else:
                        if hasattr(host_obj, 'sut_obj'):
                            host_obj = host_obj.sut_obj

                    for log in logs_list:
                        if host_obj.os_name != 'windows':
                            dest_path = os.path.join(dst, os.path.basename(log))
                        else:
                            dest_path = os.path.join(dst, log.split('\\')[-1])

                        idx = log.find("Desktop")
                        if idx >= 0:
                            log = log[idx:]
                        copy_sts = host_obj.copy_file_to_or_from_target(src_path=log, dst_path=dest_path, to_target=False)
                        if not copy_sts.get('status', False):
                            logging.error(f'Failed to copy the logs from {host}')

                # wait for processes to release file handles, else below file open for max fps fails
                time.sleep(1)
                density_message = "WLC Density (considers measured WL only)"

                if not default_mode:
                    measured = first_measured.copy()

                for key, grouped_wl in measured.items():
                    if grouped_wl["calculate"] == "max_fps":

                        folder_path = cur_log_fol_path if is_local_exe_mode else os.path.join(cur_log_fol_path, '*')

                        avg_fps = runner.calculate_fps(grouped_wl["wl_list"][0], is_local_exe_mode)
                        # Calculate target_fps according to profile
                        # if not obtainable from profile, just use default value 60 fps
                        target_fps = 60
                        param_file = grouped_wl['wl_list'][0]["start_cmd"].split()[-1]
                        found_target_kpi = False
                        if os.path.exists(param_file) and os.path.isfile(param_file):
                            with open(param_file, 'r') as f:
                                for line in f.readlines():
                                    if "KPI #2: target fps" in line:
                                        target_fps = int(line.split()[0])
                                        logging.info(f"Target fps for measured wl is {target_fps}")
                                        found_target_kpi = True
                        if not found_target_kpi:
                            workload = grouped_wl["wl_list"][0]
                            path = f"{folder_path}/log_stdout_{workload['wl']}-{workload['type']}-" \
                                   f"{workload['profile_name']}_wl_*"
                            for filename in glob.glob(path):
                                with open(filename) as f:
                                    content = f.readlines()
                                    for line in content:
                                        if "kpi target fps: " in line:
                                            matches = re.findall(r"kpi target fps: (\d+)", line)
                                            if matches:
                                                try:
                                                    target_fps = int(matches[0])
                                                    logging.info(f"Target fps for measured wl is {target_fps}")
                                                    found_target_kpi = True
                                                except ValueError:
                                                    pass
                        if not found_target_kpi:
                            if "target_fps" in grouped_wl["wl_list"][0].keys():
                                target_fps = int(grouped_wl["wl_list"][0]["target_fps"])
                                logging.info(f"Target fps for measured wl is {target_fps}")
                                found_target_kpi = True
                        if not found_target_kpi:
                            msg = "Not able to determine target FPS. Default to 60 FPS."
                            msg += "Theoretical WLC Density value might not be accurate."
                            logging.warning(f"{msg}")

                        grouped_wl["wkld_density"] = str(int(avg_fps/target_fps))
                        density_message = "Theoretical WLC Density"
                        # Currently do not stop here in order to obtain theoretical wkld density for
                        # max_fps calculation (Comment break)
                        # break

                    logging.info(f"**********************************************************************")
                    if not runner.execution_status:
                        logging.warning(f"wlc_bench execution status: FAIL")
                        logging.warning(f"Execution terminated due to an unexpected failure")
                        logging.warning(f"Received MQTT LWT or MQTT Terminated message or a WL error occurred")
                    else:
                        logging.info(f"wlc_bench execution status: SUCCESS")

                    logging.warning(f"Check log file {cur_log_fol_path} for more details. wlkd_density # is not accurate")
                    logging.info(f"{density_message}: {grouped_wl['type']} = "
                                 f"{grouped_wl['wkld_density']}")
                    logging.info(f"**********************************************************************")

            if system_metrics:
                system_metrics.write_sys_metric_xlsx()
            logging.info("Done")
        finally:
            logging.debug('Closing created objects...')

            if form_dev_vm_mgmt_obj:
                dev_obj_dict = form_dev_vm_mgmt_obj.virt_mgmt_obj_dict
            for dev_name, dev_obj in dev_obj_dict.items():
                if hasattr(dev_obj, 'vm_obj_dict'):
                    for vm_name, vm_obj in dev_obj.vm_obj_dict.items():
                        dev_obj.destroy_vm(vm_name)
                        vm_obj.close()

                if hasattr(dev_obj, 'sut_obj'):
                    dev_obj.sut_obj.close()
                else:
                    dev_obj.close()

        return 0 if runner and runner.execution_status else 1


def setup_workloads(proxy, measured):
    """
    Parse and create proxy, measured wl lists, ready for spawning
    :param proxy: list of proxy wls from yaml
    :param measured: list of measured wls from yaml
    :return: list of proxy, measured wls
    """

    workloads = []

    if proxy:
        # create objects for all wl types
        for wl in proxy["wl_list"]:
            wl["type"] = "proxy"

        workloads.append(proxy)

    if measured:
        for conglomerate_wl, wl_list in measured.items():

            # if max_fps is set, ensure instances number == 1 at
            # conglomerate_wl level AND wl_list level
            # e.g: rpos_retail_high:
            #         instances: 1
            #         wl_list:
            #           [
            #             {...
            #               instances: 1,...
            #             }
            wl_list["type"] = f"measured_{conglomerate_wl}"
            wl_list["wkld_density"] = 0

            # Flag indicating if measured WL runs were successful or not
            wl_list["is_success"] = True

            if "calculate" in wl_list and \
                    wl_list["calculate"] == "max_fps" and \
                    (len(wl_list["wl_list"]) > 1 or
                     wl_list["wl_list"][0]["instances"]) > 1:
                logging.error("calculate:max_fps has been set. # of WLs in "
                              "conglomerate WLs can only be 1. Please check yml file")
                exit(1)

            for each_wl in wl_list["wl_list"]:
                each_wl["type"] = f"measured_{conglomerate_wl}"
            workloads.append(wl_list)

    return workloads


def get_mqtt_yml_values(mode, parsed_file, parser):
    """
    Get MQTT config values from yml file
    :param mode: mqtt key from yml file
    :param parsed_file: parsed object from parse() API
    :param parser: YML parser object handle
    :return: tuple of values
    """
    # setup broker
    mqtt = parser.get(mode, parsed_file)
    mqtt_host = parser.get("host", mqtt) or "localhost"
    mqtt_port = parser.get("port", mqtt) or 1883

    return mqtt_host, mqtt_port


def get_yml_values(mode, parsed_file, parser):
    """
    Extract all values from parsed YML object
    :param mode: WLC mode, ex: breakpoint_serial
    :param parsed_file: parsed object from parse() API
    :param parser: YML parser object handle
    :return: tuple of values
    """
    # mode dictionary
    mode = parser.get(mode, parsed_file)

    # get log level
    log_level = parser.get("loglevel", mode) or 0

    # get settling time
    settling_time = parser.get("settling_time", mode)

    return settling_time, log_level


if __name__ == "__main__":
    main()
